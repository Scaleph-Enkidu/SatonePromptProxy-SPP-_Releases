# CP13 正式配对与验收记录（2026-09-26）

Compatible pair: AIChat 1.16.9 + SatonePromptProxy 5.8.20

## 验收依据与边界

用户在 2026-09-26 明确表示：“那就算CP13测试通过了，只不过需要重新计算VAD 门槛，把CP13做成一个正式的完整包，并更新github上的日志。”本次据此将 CP13 转为用户验收通过的正式配对；不把没有单独记录的检查项倒填为 PASS。

实测来源：AIChat C.9 源码 cf1788acf8bbbc1e3efc43dbe5d3bf9f85f4e347，配对 SPP CP13 C.3 源码 57ed0ea292cb087957c6d1c47090eb31742e3e67。原始日志为 LogOutput(7).log 与 SatonePromptProxy_v5.8.19(4).log；原始私人日志不提交仓库。

可复核技术片段：`savedThreshold=0.003305176; effectiveThreshold=0.0005; minSpeechSeconds=0.2; silenceSeconds=1.2; endRatio=0.4`。三次起声日志 RMS 为 0.0011、0.0012、0.0017；三个音频段为 2.23s、1.74s、3.45s，三次 ASR 均成功。第三轮失败发生在 SPP 回复格式检查，非 ASR。

## 正式交付范围

- AIChat 1.16.9 继承完整 C.9 树中的 CP12 原版共同经历及 CP13 UI、点击隔离、随机行为控制、Persona 编辑器、TTS 状态、Fun-ASR 重启、旧功能退役、PTT 预录及诊断工具。
- 持续通话保留 C.9 已测的 200ms 延后读取、原 VAD 分帧及每段直接 ASR。C.7 起已回退的 CP13-2 句间合并不在当前实际路径中；旧合并等待配置不生效。不能宣传该功能已经恢复。
- AIChat 默认起声 RMS=0.0005；结束门槛仍由起声门槛乘比例 0.4，得到 0.0002。最短语音 0.2s、静音切段 1.2s 配置不变。这是当前设备实测起点，不是适合所有设备的固定标准，也不会放大 PCM。
- 首次升级只自动迁移旧默认 0.003 和本次实测保存值 0.003305176（浮点容差 1e-8）。旧值保存为 `Vad_ThresholdBeforeCP13`，检查完成记录为 `Vad_CP13ThresholdMigrated=true`。其他校准值和后续用户修改不被自动覆盖；没有捆绑个人 cfg。
- SPP 5.8.20 沿用 CP13 C.3 功能代码；本轮只变更版本、发布配对检查及文档，不改 VAD、ASR、热词、Persona 或回复协议。新版本将 CP12/CP13 已验收功能纳入正式 Release。

## 保留的已知问题

1. 输入电平为何低于历史成功记录仍未确定：可能涉及 Sonar 的路由/增益、系统或采集路径。不得写成麦克风硬件故障已确认。新门槛使当前语音进入 VAD，不能证明所有噪声环境都不会误触发。
2. 当前 VAD 会把不足 20ms 的读取块也计作一帧，起声/静音/最大段长计时可能偏快。本版为保持已测行为不改计时，后续按实际样本数或完整帧修正并另行实测。
3. SPP 最后一轮 Primary/Repair/Fresh 的单行日文句末计数分别为 4/4/3，超过 max=2；因此 `SAFE_FALLBACK_AND_ROLLBACK`，回滚成功、跳过失败轮记忆和关系更新。返回固定“没能好好回答”提示并不表示麦克风没听清。本版不宣称此协议恢复问题已修复。
4. CP13 总体验收由用户确认；复杂 Persona 冲突、跨 Memory/Steam 切换、长时间噪声与其他设备等未由本次三句语音日志逐项证明。

## 安装

1. 退出游戏和 SPP。备份现有 AIChat.dll、`BepInEx/config/com.username.chillaimod.cfg`，以及整个 SPP 工作目录。
2. 将 AIChat_v1.16.9.zip 内的 AIChat.dll 替换到 BepInEx/plugins，确保只加载一份 AIChat.dll，移走旧 AIChatSatoneUXPatch.dll。文档不需要放入 plugins。
3. 将 SatonePromptProxy_v5.8.20.zip 解压到新目录。升级现有目录时只替换 EXE 和辅助脚本/资源，保留个人 config.json、已编辑 Persona、Memory、Relationship、Recall、OriginalGameProgress、模型及参考音频。包内 Persona/config.example 供全新安装，不要覆盖个人设置。
4. 若换了 SPP 目录，在 AIChat 中更新 SPP 启动路径。继续使用现有 BepInEx、Fun-ASR、GPT-SoVITS 与模型；完整 Mod 包不包含游戏本体、模型、参考 WAV 或 API Key。
5. 通过 Steam 启动；稳定且非零的 Steam 身份用于原版经历绑定，身份不可用仅停用该叠加，不会停用每 Memory 的 AI 好感。
6. 持续通话查看日志 `build=1.16.9`、`effectiveThreshold=0.0005`、`endThreshold=0.0002`。如果此前使用其他自定义阈值，可在设置中输入 0.0005 并保存；不要依赖停止后会恢复的临时试用开关。

## 回退

退出游戏和 SPP，恢复升级前成对程序及备份配置/数据。若只想撤销门槛调整，可把 `Vad_EnergyThreshold` 改回 `Vad_ThresholdBeforeCP13` 中的非零旧值，并保留 `Vad_CP13ThresholdMigrated=true`，避免下次再次迁移。恢复高门槛会重新出现当前低电平无法起声的可能。

从 CP13 退回旧正式 AIChat 1.16.8 / SPP 5.8.19 时，优先恢复整个升级前 SPP 目录；不要让旧程序改写唯一一份较新状态。回退到 C.9 可沿用本次 .0005 参数，仍应保留配置备份。旧 Release/tag 不移动或覆盖。

## 自动验证与实机区别

新增测试覆盖旧配置迁移、保留自定义值、迁移幂等，以及运行中降低阈值后较轻语音不被提前切段、真正静音仍能结束。沿用 AIChat 纯逻辑与 DLL 构建门禁、SPP 全量 Go 测试和真实 Windows 干净安装/Persona/ASR 管理检查。最终提交、CI、包哈希以交付的 BUILD_INFO.json 和 GitHub Release 为准。正式重编译包的配置迁移经自动测试，游戏内行为依据上述 C.9 实测和用户验收；未把重编译包另行声称为已实机测试。
