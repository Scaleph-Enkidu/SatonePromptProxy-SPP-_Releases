# SatonePromptProxy 可迁移部署指南

适用于 SatonePromptProxy 5.8.14 及以后版本。

## 推荐目录

建议把 SPP 的运行目录固定为不带版本号的路径，例如：

```text
D:\LofiMOD\
├─ SatonePromptProxy\
│  ├─ SatonePromptProxy.exe
│  ├─ config.example.json
│  ├─ config.json                 # 首次启动自动生成
│  ├─ runtime_paths.json          # 自动生成的本机路径缓存
│  ├─ SatonePersona_v4.5.txt
│  ├─ embedding_worker.py
│  ├─ profiles_26.csv
│  ├─ SatoneASRHotwords_v1.json
│  └─ satone_funasr_server_v1.py
│
├─ AI\
│  ├─ FunASR-Runtime\
│  │  ├─ .venv\Scripts\python.exe
│  │  └─ satone_funasr_server.py
│  └─ Fun-ASR-Nano-2512\
│
└─ mayuri-voice\
   └─ refs\
```

Release ZIP 文件名仍使用正式名称和版本号，例如
`SatonePromptProxy_v5.8.14.zip`；实际运行目录建议固定为
`SatonePromptProxy`，这样 AIChat 不需要在每次 SPP 升级后重新修改 EXE 路径。

## 首次启动

Release 不包含用户的实际 `config.json`。

首次启动时：

1. 如果 `config.json` 已存在，SPP 直接使用，不用包里的示例覆盖；5.8.23 的唯一例外是旧默认阈值 `auto_consolidate_threshold_tokens=24000` 首次启动会先备份为 `config.json.before_v5.8.23`，再改为 `32000`。自定的其他阈值和其余字段保留。
2. 如果 `config.json` 不存在而 `config.example.json` 存在，SPP 自动复制生成新的 `config.json`。
3. 如果两个文件都不存在，SPP 会输出明确错误并退出。

`config.example.json` 不应包含开发电脑的绝对路径。

## Fun-ASR 自动发现与缓存

当 `asr.python`、`asr.server_script`、`asr.model_path` 留空时，
SPP 会从自身目录向上搜索标准目录：

```text
AI\FunASR-Runtime\.venv\Scripts\python.exe
AI\FunASR-Runtime\satone_funasr_server.py
AI\Fun-ASR-Nano-2512

FunASR-Runtime\.venv\Scripts\python.exe
FunASR-Runtime\satone_funasr_server.py
Fun-ASR-Nano-2512
```

首次发现完整路径后，会写入 `runtime_paths.json`。

下次启动优先级为：

```text
config.json 中的有效显式路径
>
包内 5.8.18 ASR 服务脚本（仅 server_script）
>
runtime_paths.json 中仍然有效的缓存路径
>
标准目录自动发现
```

如果电脑迁移、盘符变化或目录移动导致缓存失效，SPP 会忽略旧缓存，
重新搜索并自动刷新 `runtime_paths.json`。因此 `runtime_paths.json`
属于机器本地缓存，不是必须备份的数据。

可通过：

```text
http://127.0.0.1:11435/asr/status
```

查看 SPP 当前解析出的 Python、server script、model path，以及
`path_source`（manual / cached / discovered / mixed）。

## 参考语音

默认参考语音路径保持可迁移的相对布局。推荐：

```text
D:\LofiMOD\mayuri-voice\refs
```

SPP 会尝试查找当前 SPP 目录内及其上一级的
`mayuri-voice\refs`。如需完全自定义路径，可在
`emotion_tts.ref_root` 中填写绝对路径。

状态检查：

```text
http://127.0.0.1:11435/tts/status
```

## 换电脑时需要迁移的用户数据

CP12-1 feature 分支新增全局 `OriginalGameProgress.json` 及其 `.prev` 上一有效版本；未来使用原版进度叠加时，两者应和原有记忆文件一并备份/迁移。5.8.19 正式版不生成这些文件；搬到另一台电脑后仍须通过游戏运行时重新验证 Steam 身份，不能靠旧账本自动绑定当前玩家。

根据是否希望延续旧会话，可复制：

```text
config.json
memory_profiles\
SatoneRelationship.json
conversation_state.json
SatoneArchive.jsonl
SatoneRecall.db
usage_stats.json
```

同时复制或重新安装大型外部资源：

```text
FunASR-Runtime
Fun-ASR-Nano-2512
GPT-SoVITS 及其语音模型
mayuri-voice\refs
本地 Embedding 模型（如已安装）
```

`runtime_paths.json` 可以复制，也可以不复制。若复制后路径已经失效，
SPP 会自动重新发现并更新。

## 外部服务失败时

Fun-ASR、GPT-SoVITS、参考 WAV 或 Recall Embedding 不可用时，
SPP 应保持主 HTTP 服务运行，并通过对应状态接口给出错误。
这些可选服务缺失不应导致 SPP 因路径问题直接退出。

真正会阻止 SPP 启动的情况主要包括：

- `config.json` / `config.example.json` 无法读取或 JSON 损坏；
- 监听地址非法或不是 loopback；
- 本地核心状态无法安全初始化；
- 监听端口无法绑定。

## ASR 热词与版本核对（5.8.18）

5.8.18 的发布包自带 `SatoneASRHotwords_v1.json` 与 `satone_funasr_server_v1.py`；
现有 `AI\\FunASR-Runtime` 提供 Python 虚拟环境，`AI\\Fun-ASR-Nano-2512` 提供本地模型。
默认情况下 SPP 优先使用包内的服务脚本，`asr.server_script` 的显式配置优先于它；
如果 9881 上已有其他服务，SPP 会继续连到已有服务。不要同时开两个 SPP。

需要确认运行的是支持热词的服务，请查看 `http://127.0.0.1:11435/asr/status`：
`hotwords_version=1`、`hotwords_count>0`、`hotwords_backend_supported=true`，
以及 `server_script` 路径。若状态显示 `false`，先检查旧 9881 进程和显式脚本路径；
单有词库文件不代表模型已经收到热词。词库 JSON 随候选包一起复制，
不必修改 Fun-ASR 模型权重或运行环境中的旧脚本。

`asr.language=auto` 时发送日语和中文词；强制 `中文` 或 `日本語` 时只发送所选语言。
生僻姓名和器物词倾向会改善，但热词不是语音识别正确率保证；原始识别仍以
游戏 `BepInEx/LogOutput.log` 的 `[ASR] 服务器返回` 和 SPP 统一日志为准。
