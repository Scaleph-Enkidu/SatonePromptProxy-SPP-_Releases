"""Portable /asr adapter for the Fun-ASR-Nano model and the SPP hotword list.

Runs inside an existing FunASR-Runtime Python environment; it does not install or
download a model. SPP sets SATONE_FUNASR_MODEL and SATONE_FUNASR_HOTWORDS_PATH.
"""

import json
import logging
import os
import tempfile
import threading
from email.parser import BytesParser
from email.policy import default
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit


VERSION = 1
MAX_REQUEST_BYTES = 16 * 1024 * 1024
logging.basicConfig(level=logging.INFO, format="[Fun-ASR] %(levelname)s %(message)s")
inference_lock = threading.Lock()


def load_hotwords():
    path = os.environ.get("SATONE_FUNASR_HOTWORDS_PATH", "")
    if not path:
        return []
    with open(path, encoding="utf-8") as f:
        manifest = json.load(f)
    if manifest.get("version") != VERSION or not isinstance(manifest.get("entries"), list):
        raise ValueError("unsupported ASR hotword manifest")
    return list(dict.fromkeys(
        word.strip() for entry in manifest["entries"]
        for word in (entry["ja"], entry["zh"], *entry.get("aliases", []))
        if isinstance(word, str) and word.strip()
    ))


def parse_audio(content_type, body):
    if not content_type.lower().startswith("multipart/form-data"):
        raise ValueError("multipart/form-data required")
    message = BytesParser(policy=default).parsebytes(
        b"MIME-Version: 1.0\r\nContent-Type: " + content_type.encode("ascii")
        + b"\r\n\r\n" + body
    )
    if not message.is_multipart():
        raise ValueError("invalid multipart body")
    for part in message.iter_parts():
        if part.get_param("name", header="content-disposition") in ("file", "audio"):
            data = part.get_payload(decode=True)
            if data:
                return data
    raise ValueError("audio file missing")


def make_handler(model, default_hotwords):
    class Handler(BaseHTTPRequestHandler):
        def send_json(self, status, value):
            body = json.dumps(value, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if urlsplit(self.path).path == "/health":
                self.send_json(200, {"ok": True, "hotwords_supported": True,
                                     "hotwords_version": VERSION,
                                     "hotwords_count": len(default_hotwords)})
            else:
                self.send_json(404, {"error": "unknown path"})

        def do_POST(self):
            if urlsplit(self.path).path != "/asr":
                self.send_json(404, {"error": "unknown path"})
                return
            try:
                n = int(self.headers.get("Content-Length", "0"))
                if n <= 0 or n > MAX_REQUEST_BYTES:
                    raise ValueError("audio request size outside supported range")
                wav = parse_audio(self.headers.get("Content-Type", ""), self.rfile.read(n))
                query = parse_qs(urlsplit(self.path).query)
                # SPP supplies one comma-delimited list; direct requests use the
                # same packaged manifest through the environment variable.
                words = [w.strip() for w in query["hotwords"][0].split(",") if w.strip()] \
                    if "hotwords" in query else default_hotwords
                if len(words) > 64 or any(len(w) > 48 for w in words):
                    raise ValueError("hotword list too large")
                language = (query.get("language") or query.get("lang") or ["auto"])[0].strip()
                args = {"cache": {}, "batch_size": 1, "hotwords": words}
                if language and language.lower() != "auto":
                    args["language"] = language
                with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
                    f.write(wav)
                    wav_path = f.name
                try:
                    with inference_lock:
                        result = model.generate(input=[wav_path], **args)
                finally:
                    os.unlink(wav_path)
                recognized = result[0].get("text", "") if result else ""
                logging.info("asr result language=%s hotwords=%d text_chars=%d",
                             language, len(words), len(recognized))
                self.send_json(200, {"text": recognized})
            except ValueError as e:
                logging.warning("invalid /asr request: %s", e)
                self.send_json(400, {"error": str(e)})
            except Exception:
                logging.exception("/asr inference failed")
                self.send_json(500, {"error": "ASR inference failed; check SPP log"})

        def log_message(self, fmt, *args):
            # Health is polled frequently; retain non-200 responses and all other requests.
            if self.command == "GET" and self.path == "/health" and len(args) > 1 and str(args[1]) == "200":
                return
            logging.info("HTTP %s", fmt % args)

    return Handler


def main():
    from funasr import AutoModel

    model_dir = os.environ["SATONE_FUNASR_MODEL"]
    if not Path(model_dir).is_dir():
        raise ValueError("SATONE_FUNASR_MODEL must be a local model directory")
    words = load_hotwords()
    logging.info("loading local model, hotword manifest v%d with %d words", VERSION, len(words))
    model = AutoModel(model=model_dir, trust_remote_code=True)
    host = os.environ.get("SATONE_FUNASR_HOST", "127.0.0.1")
    if host not in ("127.0.0.1", "localhost", "::1"):
        raise ValueError("ASR adapter only listens on loopback")
    port = int(os.environ.get("SATONE_FUNASR_PORT", "9881"))
    with ThreadingHTTPServer((host, port), make_handler(model, words)) as server:
        logging.info("ready on %s:%d; hotwords_supported=true", host, port)
        server.serve_forever()


if __name__ == "__main__":
    main()
