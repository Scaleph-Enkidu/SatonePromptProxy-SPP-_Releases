AIChat 1.16.65 / SPP 5.8.42
见《安装与实机测试说明.md》。发布页：https://github.com/Scaleph-Enkidu/SatonePromptProxy-SPP-_Releases
