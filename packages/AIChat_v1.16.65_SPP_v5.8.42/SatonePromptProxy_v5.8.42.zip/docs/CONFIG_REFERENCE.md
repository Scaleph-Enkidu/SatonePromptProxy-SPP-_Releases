# SatonePromptProxy Configuration Reference（5.8.23）

SPP 从 EXE 同目录读取：

```text
config.json
```

启动时读取现有 `config.json`，缺失字段会补齐默认值并重新保存。5.8.23 在旧默认自动记忆阈值迁移前，会额外保存原配置备份。

## CP14-2 独立连接文件（功能分支，未发布）

`connections.v1.json` 保存候选配置与全局 revision；`connection_credentials.v1.json` 在同目录保存 Key 及来源/修订记录。Unix 写入前设置 0600；Windows 使用仅当前用户与 LocalSystem 可访问的受保护 DACL 创建临时文件，并在写入任何 Key 前读回 DACL 校验；启动读取旧凭据文件前重设并读回其 DACL。文件系统不支持或权限检查失败时，新连接管理不可用。仍是本机明文，管理员、SYSTEM 和拥有目录写权限的账户不能据此视为隔离。不要把凭据文件同步到仓库或聊天日志。损坏或未知 schema 会禁用新连接管理，旧 OpenAI 聊天仍启动；请检查文件后再修复，程序不会静默重置。管理请求有 32 KiB 的完整 body 上限，超限返回 400。连接测试是主动操作，可能计费，发送 `max_tokens=128` 作为探测预算；供应商不支持这个字段时会明确失败。开始探测前将当前 `verification` 清空并持久标记 `last_test=running`，成功只记 `reachable`；失败持久保存 `last_test=failed`，历史成功留在 `last_success`，但不能充当当前验证。写盘失败时不发送探测；完成后的落盘失败保留 `running` 标记供重启后拒绝旧成功证据。没有默认连接或自动迁移。现有 `config.json` 和云端状态仍按 5.8.23 工作。

CP14 候选验证记录以 `config_fingerprint` 绑定具体配置及凭据 revision；历史成功不会随模型/地址编辑重新归属。`last_test.test_id` 决定同连接最新探测的写回权，不使用其他连接也会改变的全局 revision。缺少指纹的旧验证记录降为历史，须重测。官方 DeepSeek 探测显式关闭 thinking，通用中转不接收专有 thinking 参数；两者都保留 128 token 上限。

## CP19-1 候选：连接级思考强度（`reasoning_selection`）

连接配置新增 `reasoning_selection`（`auto | none | low | medium | high | max`），与模型 ID 完全独立。`auto` 不发送显式强度、使用供应商默认；手动档位只有在供应商/模型能力判断或实际参数探测接受后才生效，不做静默降级。

- **迁移**：旧 `connections.v1.json` 首次启动按预设补齐——旧 DeepSeek 连接迁移为 `none`（保持此前本地链路 thinking=disabled 的行为），OpenAI／Claude／Gemini／Ollama／中转迁移为 `auto`；配置 schema 升为 v2 并原子落盘。旧 SPP 不能读取 v2 文件，降级前请备份连接配置。
- **指纹与验证**：`reasoning_selection` 进入 `config_fingerprint`；改变档位会使旧验证失效并必须重测。`reachable` 仍表示基础可达；手动档位记为 `reachable_reasoning`，表示“按该档位发送的请求被接受”（允许 `finish_reason=length`，因为推理可能吃满探测预算）。探测预算：DeepSeek `none` 128 / `auto`·`low` 256 / `medium`·`high` 512 / `max` 1024；OpenAI／Claude／Gemini／Ollama 1024；通用中转保持 128。
- **供应商行为（2026-09-30 官方文档核对）**：OpenAI 发送 `reasoning_effort`；官方文档明确 GPT-6 Astra 不支持 `none`、GPT-6.1 Sol 不支持 `none/minimal`，本 CP 不提供 `xhigh`。DeepSeek 发送 `thinking` 与 `reasoning_effort`，`none` 明确关闭 thinking，`medium` 按官方兼容映射为 `high`（UI/诊断会显示 requested/effective/source）。Claude／Gemini／Ollama／中转只接受 `auto`，不会收到供应商专有字段。
- **作用域**：主聊天 `primary`／`repair`／`fresh` 使用该轮冻结的档位；记忆摘要、关系 updater、窗口分类、压力分类等后台任务继续使用各自设置或原行为，不被主档位传播。
- **协议**：`/connections` 响应 `api_version` 升为 2；未升级的 AIChat 不发送新字段，按预设默认处理。新 AIChat 对 `api_version=1` 的旧 SPP 隐藏该设置并省略字段，避免旧 SPP 的连接 PUT 严格解码拒绝未知字段。

## CP20 候选：原版剧情知识判定（提示词 v3）

AIChat 每轮对话开始时读取当前存档的剧情进度，只向 SPP 发送已解锁知识点 ID 与证据类型（`story_knowledge: {revision, items:[{id, source}]}`）；知识点文案、反应意图与敏感度全部保存在 SPP，不进 AIChat，也不写回存档。

- **判定**：`FinishReadMainEpisodeNumber`（数值门槛）与 `PlayedScenarioGroupIDs`（组集合）取或集；两条证据都不可读时 fail-closed（空知识列表）。每条链只注入已解锁的最高阶段，最多 12 条。读取失败时使用本次游戏会话内最近一次成功快照；读档/换档会清空该粘性快照。
- **注入**：提示词版本升为 v3；规则块 `[SATONE_STORY_KNOWLEDGE]` 常驻 system 前缀，已解锁事实清单放入 envelope 的 `satone_turn_context.story_knowledge`（尾部）。未列出的剧情不得表示记得、不得确认细节、不得剧透；已列出的视为 established self-knowledge，可与 `[SATONE_UNVERIFIED_PAST_CLAIM]` 叠加。
- **冻结与失败策略**：知识集合随该轮 prompt snapshot 冻结，repair/fresh/recovery 原样复用；未知 revision/ID、超限或来源不符时丢弃整个知识块并记录诊断，不阻断对话本身。v2 历史的 prepared prompt 仍按原 StableCore/messages 重放，不重新解释。
- **边界（v1）**：不进入长期记忆、关系数值或 recall；不主动播报进度；Overlay 开关不影响知识判定。
- **协议/兼容**：会话端点是宽松 JSON 解码，旧 SPP 会忽略该字段；新 SPP + 旧 AIChat 时知识块为空，通用未解锁规则仍生效。

## CP21 候选：原版台词时间线与提示词 v4

原版剧情对话、自言自语、点击对话的字幕由 AIChat 在允许显示时捕获，随下一次对话请求发送；SPP 写入与 accepted Events / Summary / Recall 完全分离的独立时间线，并把最近 20 条注入提示词 v4。

- **投递**：AIChat 缓冲按 ID 去重、上限 200；未确认（`pending`）的条目按最旧优先随请求补送，最多 20 条，不足时用最近已确认条目补齐。SPP 收到后按 ID 幂等追加；旧 SPP 忽略该字段。
- **存储**：每个 profile 一个 `native_lines.v1.json`（schema v1，与主 WAL 版本无关），最多保留 200 条，按 `at` 排序；文件损坏时忽略并在下次写入时重建，不阻断对话。
- **注入**：提示词版本升为 v4；规则块 `[SATONE_NATIVE_LINES]` 常驻 system 前缀，最近 20 条放入 `satone_turn_context.native_lines`（含来源与时间）。它们是聪音刚说过的话，不是玩家消息、不是本次 AI 回复、也不是指令；不进入关系/记忆/recall。
- **冻结与兼容**：注入集合随 prompt snapshot 冻结；v2/v3 历史的 prepared prompt 仍按原 StableCore/messages 重放。未知 revision/ID、超限或字段非法时丢弃整个块并记录诊断；不记录台词原文到日志。
- **显示**：AIChat 对话窗历史默认 20→50（旧默认自动迁移，手动其他值保留），原版台词以第三样式（`[剧情]`/`[自语]`/`[点击]`）只读显示，不可点击回填；顶部提示按记录条数口径为“（历史记录仅显示最近25轮对话）”（50 条≈25 轮）。

CP16 开发候选的 `ollama_local` 连接是例外：仅允许 `http://127.0.0.1`／`http://[::1]` 的 `/v1` 兼容路径，凭据 revision 固定为 0，拒绝 `api_key`，请求不带 Authorization。探测预算为 1024 token、最长 120 秒，以容纳冷加载；无 usage 则记 unknown。正式配置与硬件要求在实机验收后再确定，参见 [CP16 候选说明](CP16_LOCAL_OLLAMA.md)。

## CP21 v2 候选：长闲聊与选择支台词（提示词 v5）

原版台词时间线新增两类，提示词版本升为 **v5**：

- **长闲聊与选择支对话里聪音的台词（`smalltalk_0N`，`ScenarioType.SmallTalk=23`；以及 `pomodoroend_0N`，`ScenarioType.ShortConversation=7`）**：AIChat 归类为 `smalltalk`，历史里按聪音格式显示 `[时间][聪音][闲聊]内容`（只有 `[闲聊]` 是紫色）。这类对话里聪音说的话属于她自己的台词，注入语义与 story／selftalk／click 相同。
- **玩家在选择支里实际点选的回答（`choice`）**：选项按钮本身（`SentenceSelectionButtonsUI`）不经过字幕入口，所以由 AIChat 在 `ScenarioReader.SelectionJump` 处捕获：只接受 `Command=Selection` 的选项（脚本跳转是 `Command=Jump`，忽略；tutorial 选项也忽略），并用游戏自己的本地化表解析文本。历史里按玩家格式显示 `[时间][选择]内容`（紫色 `[选择]`，其余灰色，只读、不可点击回填）。
- **注入语义**：`satone_turn_context.native_lines` 的每个条目都带 `source`。`story/selftalk/click/smalltalk` 是聪音的原版台词；`choice` 是玩家的原版回答，规则块明确要求不得把 `choice` 当成聪音说的话、也不得反向引用。旧版本（v2/v3/v4）的 prepared prompt 仍按各自存储的 StableCore/messages 原样重放。
- **前向兼容**：`source` 校验改为**逐条跳过**未知来源（记录 `[SPP/NativeLines][WARN] dropped_unknown_source=N`），已知条目继续可用；revision/ID/时间/长度异常仍整块丢弃。
- **显示格式（AIChat）**：原版台词统一为 `[时间][聪音][类别]内容`，只有类别标签用紫色；`choice` 用玩家格式。分类优先按游戏 `ScenarioType`（前缀表仍优先），因此组名由 master data 决定的两类也能稳定命中。

## CP19-1 r3 候选：思考降级兜底、预算建议与音色包说明

思考内容与正文共用同一条输出预算；预算不足时供应商会返回 `finish_reason=length` 且正文为空。r3 在主聊天链路上加了兜底与可见提示：

- **兜底顺序**（仅发生在“没有正文”的截断/空回复上）：先用**同一思考档位 + 更大预算**重试（DeepSeek／中转上限 32768，OpenAI 上限 16384，且必须仍在声明窗口内），再按供应商安全的最低档位重试（DeepSeek `none`；OpenAI `low`／`none`；中转保持原参数）。所有重试都在同一条 durable 任务记录内完成，日志前缀 `[SPP/ReasoningFallback]`；耗尽时该轮仍然失败，不会假装成功。
- **元数据与提示**：被兜底救回的回复在 `/v1/chat/reply` 里多带 `reasoning_fallback{requested,effective,reason,attempts,degraded}`。只有 `degraded=true`（真的降低了思考档位）时 AIChat 才在对话窗顶部中央显示白色 `[思考降级]`；仅放大预算的救回不显示。档位本身不会被静默改写，连接配置与验证指纹不变。
- **输出预算建议**：High 建议 ≥ 8192，Max 建议 ≥ 16384（AIChat 在上述档位下会给出风险提示与“一键调整输出预算”）。声明窗口还要为对话历史留出 5% 窗口余量与 ≥4096 token 输入空间，因此 Max 的建议值需要 `context_window_tokens` ≥ 21557（16384 + 1077 + 4096）。
- **与自动整理阈值的关系**：`auto_consolidate_threshold_tokens` 会被有效窗口限制（`window - margin - max_output_tokens`）。想让 34000 真正生效，需要 `context_window_tokens=65536` 且输出预算约 8192（`65536-3277-8192=54067`）；沿用 32768 窗口时会被压到 22938（O=8192）或 30106（O=1024）。更改 `context_window_tokens` 会使连接指纹失效，必须重新测试连接后才能启用。

## CP15 开发候选：Claude／Gemini 独立连接

该分支在 5.8.26 基线上增加 `claude_official`、`gemini_official` 两种预设，仅允许各自官方 origin 与固定兼容路径。连接沿用独立 ID、Key 版本和冻结生效快照；Claude 可选 `workspace_id`（仅合法 `wrkspc_...`），SPP 会在该连接的所有模型请求中发送 `anthropic-workspace-id`。变更工作区需要重新明确绑定 Key，Gemini／其他预设不得设置此字段。Claude 和 Gemini 的连接探测使用 `max_tokens=1024`，因此上文 128 token 说明只适用于旧 DeepSeek／通用中转。连接探测成功依旧只说明短请求可达；真实 API 与游戏内行为待验收。详见 [CP15 候选说明](CP15_PROVIDER_COMPAT.md)。

## Core

| Field | Default | Meaning |
| --- | --- | --- |
| `listen` | `127.0.0.1:11435` | 本地 HTTP 服务；必须是 loopback |
| `openai_responses_url` | OpenAI Responses API | LLM 上游 |
| `openai_conversations_url` | OpenAI Conversations API | 持久化 Conversation |
| `persona_file` | stable 5.8.12: `SatonePersona_v4.4.txt`; develop CP7 default: `SatonePersona_v4.5.txt` | 全局 Persona；显式旧路径不会被 loadConfig 静默迁移 |
| `state_file` | `conversation_state.json` | 当前 Profile Conversation 状态 |
| `usage_file` | `usage_stats.json` | Token / cost 统计 |
| `memory_file` | `SatoneMemory.json` | 当前 Profile 长期 Memory |
| `model_override` | empty | 非空时覆盖 AIChat 请求 model |
| `request_timeout_seconds` | 180 | OpenAI / upstream HTTP timeout |
| `max_output_tokens` | 0 | Responses max output；0 表示不主动限制 |
| `reasoning_effort` | empty | 旧 Responses 云端路径的主聊天 reasoning 参数；新连接改用 `connections.v1.json` 的 `reasoning_selection` |

## Memory

| Field | Default |
| --- | ---: |
| `auto_memory_enabled` | true |
| `auto_consolidate_threshold_tokens` | 32000 |
| `recent_context_keep_tokens` | 12000 |
| `memory_summary_target_tokens` | 2500 |
| `memory_summary_max_output_tokens` | 3200 |
| `memory_reasoning_effort` | `low` |

自动整理的触发依据是一次有效主聊天回复的 Responses API `usage.input_tokens`，包含固定人格、记忆、好感、格式规则和近期对话，也包含缓存命中的输入；到 32,000 后才安排整理旧对话。`recent_context_keep_tokens=12000` 仅用于粗估应保留的 user/assistant 原始对话，不从 32,000 中预留或扣除其他提示词；因此两者都不是硬性输入上限。

已有 `config.json` 的该字段若为旧默认值 `24000`，5.8.23 首次启动会先写 `config.json.before_v5.8.23` 原样备份，再把该字段改成 `32000` 并写入一次性标记 `_auto_memory_threshold_v5_8_23_migrated=true`。若此前刻意把它设为 `24000`，这次也会迁移；启动后可以手动改回，标记会阻止重复迁移。设为其他值的配置保持原值。长期记忆 `memory_summary_target_tokens=2500` 是摘要写作目标，`memory_summary_max_output_tokens=3200` 是独立请求的输出上限，不限制长期记忆文件的主聊天输入长度。

## Environment

```json
"environment_awareness": true
```

只在时间、日期、星期、对话持续时间等相关问题上临时注入本机环境信息。

## Archive / Recall

```json
{
  "archive_file": "SatoneArchive.jsonl",
  "chat_log_file": "SatoneChat.txt",
  "recall_db_file": "SatoneRecall.db",
  "recall_enabled": true,
  "recall_mode": "triggered",
  "recall_top_k": 3,
  "recall_candidate_limit": 30,
  "recall_min_score": 0.74,
  "recall_strong_score": 0.84,
  "recall_max_injected_chars": 3600
}
```

`recall_mode`：

```text
off
triggered
always
```

通常不建议 `always`，因为旧对话会在普通闲聊中产生不必要干扰。

## Embedding

```json
{
  "embedding_enabled": true,
  "embedding_python": "",
  "embedding_worker_file": "embedding_worker.py",
  "embedding_model_id": "intfloat/multilingual-e5-small",
  "embedding_model_dir": "models/multilingual-e5-small",
  "embedding_device": "cpu",
  "embedding_auto_start": true,
  "embedding_rebuild_after_install": true
}
```

`embedding_python` 为空时会自动寻找：

```text
runtime/python.exe
附近目录中的 GPT-SoVITS runtime/python.exe
系统 python3 / python
```

注意：v5.8.6 的 Python worker 当前源码明确执行 `model.to("cpu")`，因此 `embedding_device` 并不会把 E5 模型真正迁到 GPU。

## Sentence Protocol

```json
"sentence_protocol": {
  "runtime_contract_enabled": true,
  "repair_enabled": true,
  "repair_max_attempts": 1,
  "repair_max_output_tokens": 1200,
  "segment_max_chinese_chars": 41,
  "segment_max_japanese_chars": 100,
  "segment_max_sentence_ends": 2
}
```

### runtime_contract_enabled

为正常聊天的每一次 Responses API 请求注入 Runtime Output Contract。建议保持 `true`。关闭后，格式主要依赖 Persona 自己遵守。

### repair_enabled

主模型输出未通过 SPP 协议 validator 时，允许执行 stateless Repair。建议保持 `true`。

### repair_max_attempts

默认 1。Repair 是异常路径，不建议为了追求格式把次数调高，否则单次失败会放大延迟和费用。

### repair_max_output_tokens

Repair 请求的输出上限，默认 1200。Repair 只应恢复格式/语言字段，不负责重新展开答案。

### segment_max_chinese_chars

单个 Simplified Chinese 字幕字段的主要 hard limit，默认 **41**，并且**包含标点**。超过后该轮被判为 protocol-invalid，并进入 stateless Repair。

Runtime Output Contract 同样每轮要求 Field 3 <= 41；如果超出，应拆成更多 JP/ZH 对齐行，而不是删减或概括内容。

该值与 AIChat 已有的 41 字符字幕显示上限保持一致；AIChat 仍保留自己的显示层拆分作为最终兜底。

### segment_max_japanese_chars

单个日文 TTS semantic segment 的辅助 Validator 硬上限，默认 **100**。v5.8.8 主要长度标准已改为中文 Field 3 <= 41；100 只保留为日文异常保护。

### segment_max_sentence_ends

单个 segment 允许的句末标点（`。！？!?`）数量上限，默认 **2**。超过时进入 Protocol Repair，避免把多句知识说明塞成一个很长的 GPT-SoVITS 请求。

这两个字段与 AIChat 的 41 字符字幕显示拆分无关。

如果 Repair 最终失败，v5.8.9 会使用本地 safe spoken fallback，而不是把 malformed raw text 返回 AIChat。


## Relationship

```json
"relationship": {
  "enabled": true,
  "file": "SatoneRelationship.json",
  "updater_enabled": true,
  "update_every_n_exchanges": 1,
  "reconcile_every_n_exchanges": 20,
  "updater_max_output_tokens": 500,
  "updater_reasoning_effort": "low",
  "max_absolute_delta_per_update": 2,
  "initial_affection": 10,
  "initial_trust": 10,
  "initial_comfort": 10,
  "initial_openness": 10,
  "memory3_max_affinity_preset": true
}
```

### enabled

总开关。关闭后不会创建/注入 Relationship，也不会运行 updater。

### file

每个 Memory Profile 的 Relationship 文件名。默认 `SatoneRelationship.json`。

### updater_enabled

是否在成功对话后异步运行 Relationship Updater。

### update_every_n_exchanges

默认 1，即每轮检查。调成 2 或更高可降低额外 API Token，但会降低关系事件捕捉及时性。

### reconcile_every_n_exchanges

默认 20。执行低频关系校准；Reconcile 不应再次增加长期 affection/trust/comfort/openness。

### updater_max_output_tokens

Relationship JSON updater 输出上限，默认 500。

### updater_reasoning_effort

默认 `low`。Updater 是保守状态分类任务，不需要主聊天同等级 reasoning。

### max_absolute_delta_per_update

SPP 对 affection / trust / comfort / openness 单次变化的硬 clamp。默认 2。

### initial_affection / initial_trust / initial_comfort / initial_openness

v5.8.10 新增。memory1 / memory2 首次创建 Relationship 文件，或调用 `/relationship/preset` 的 `default` / `reset` 时使用。默认全部为 `10`。

已有 `SatoneRelationship.json` 不会因为升级被覆盖。

### memory3_max_affinity_preset

仅当 memory3 的 Relationship 文件尚不存在时生效。默认 true：初始化 memory3 为 100/100/100/100，用于满好感 A/B 测试。已有文件不会被覆盖。

Relationship 详细语义见 [RELATIONSHIP_SYSTEM.md](RELATIONSHIP_SYSTEM.md)。

## ASR

```json
{
  "enabled": true,
  "upstream_url": "http://127.0.0.1:9881",
  "language": "auto",
  "auto_start": true,
  "auto_restart": true,
  "stop_with_proxy": true,
  "python": "",
  "server_script": "",
  "model_path": "",
  "health_url": "",
  "start_timeout_seconds": 120,
  "monitor_interval_seconds": 60
}
```

### auto_start

SPP 启动时先 health check。

已有服务则复用；没有服务才尝试启动。

### auto_restart

后台 monitor 发现服务不可用，而且没有仍在运行的 owned process 时重新启动。

### stop_with_proxy

只对 SPP 自己启动的 owned process 生效。

### python / server_script / model_path

留空时使用可迁移自动发现。5.8.14 起解析优先级固定为：

```text
config.json 中仍有效的显式路径
>
runtime_paths.json 中仍有效的自动缓存
>
标准目录自动发现
```

当前针对项目布局的候选包括：

```text
AI/FunASR-Runtime/.venv/Scripts/python.exe
AI/FunASR-Runtime/satone_funasr_server.py
AI/Fun-ASR-Nano-2512
```

以及没有 `AI/` 层级的对应路径。首次自动发现完整 Python / server script / model 后，会写入同一 SPP 运行目录的 `runtime_paths.json`。下次启动若缓存仍有效直接复用；如果换盘符或移动目录导致缓存失效，SPP 会重新自动发现并刷新缓存。该缓存是机器本地可再生状态，不进入 Release，也不是必须迁移的用户数据。

如果显式路径已经失效，SPP 会记录 warning 并继续 cache/discovery，而不是让失效配置阻断自动发现。当前解析结果和来源可查看 `GET /asr/status`。

### health_url

为空时自动使用：

```text
{upstream_url}/health
```

## Emotion TTS

公开包只自带基础音色（`Neutral` 参考音频 `mayuri-voice/refs/MAY_1158_Neutral.wav`）。其他情绪音色属于玩家自备的可选下载：缺少某个情绪参考时，SPP 会在启动自检中记录一条 `[VoiceProfile]` 提示，并在该情绪被请求时自动回退到 `fallback_profile`（默认 `Neutral`），仍然正常发声。缺音色不是“聪音不说话”的原因。

主要字段：

```json
{
  "enabled": true,
  "upstream_url": "http://127.0.0.1:9880",
  "ref_root": "",
  "fallback_profile": "Neutral",
  "match_window_seconds": 120,
  "profiles": {},
  "mapping": {}
}
```

### ref_root

参考音频根目录。正式 example 默认留空，由运行时使用可迁移的相对布局；不应在 example 中写死开发电脑盘符。

如果配置路径为空或无效，SPP 还会尝试：

```text
./mayuri-voice/refs
../mayuri-voice/refs
```

### profiles

每个 Profile：

```json
{
  "path": "MAY_xxxx_Emotion.wav",
  "prompt": "日文参考台词",
  "lang": "ja"
}
```

如果 `prompt` 为空，SPP 会尝试读取 WAV 同名 `.txt`。

### mapping

Emotion label → Voice Profile name。

v5.8.9 当前仍是 26 → 26 一一对应。

## Memory Profiles

```json
{
  "enabled": true,
  "root": "memory_profiles",
  "active": "memory1"
}
```

固定内部 ID：

```text
memory1
memory2
memory3
```

不要自行改成任意数量。v5.8.9 源码是固定三档，而不是动态 Profile 注册系统。

## Pricing

`pricing` 只用于 SPP 本地估算费用。

它不会影响 OpenAI 实际计费。

模型价格变化后，应更新这里，否则 Dashboard 的 estimated cost 会偏离实际账单。
