# CP14 多 API 状态 — 计划 v1.1

## CP21 开发候选：原版台词时间线（2026-09-30，本地）

开发分支 `feature/cp21-native-lines-history` 在 CP20 候选上新增独立原版台词时间线（每 profile 一个 `native_lines.v1.json`，上限 200，按 ID 去重）与提示词 v4（注入最近 20 条）；不进 accepted Events / Summary / Recall。尚未真实 API、Unity 实机、独立审查或正式 CI；边界见 [CONFIG_REFERENCE](CONFIG_REFERENCE.md)。

## CP20 开发候选：原版剧情知识（2026-09-30，本地）

开发分支 `feature/cp20-story-knowledge` 在 CP19-1 候选上新增剧情知识判定与提示词 v3：AIChat 只发送已解锁 ID + 证据类型，SPP 注入事实与双侧规则；fail-closed，不阻断对话，不进记忆/关系/recall。尚未真实 API、Unity 实机、独立审查或正式 CI；边界见 [CONFIG_REFERENCE](CONFIG_REFERENCE.md)。

## CP19-1 开发候选：连接级思考强度（2026-09-30，本地）

开发分支 `feature/cp19-1-reasoning-effort` 在 5.8.33 基线上新增 `reasoning_selection`，把模型与思考档位拆开；`auto` 省略显式参数，手动档位经能力表或实际参数探测接受后才生效。旧 DeepSeek 连接迁移为 `none`，其他预设迁移为 `auto`；档位进入连接指纹并区分 `reachable` / `reachable_reasoning`。只影响主聊天 primary/repair/fresh，后台任务不被传播。尚未真实 API、Unity 实机、独立审查或正式 CI；详细边界见 [CONFIG_REFERENCE](CONFIG_REFERENCE.md)。

## R0～R6 连续改造：第二轮冻结（2026-09-27T23:44:36.011709+09:00；当前入口）

SPP 已测候选 `59caec46148d1a423685f397dc434cd178a96712`；AIChat 已测候选 `28e515bdbf90d1a33909021b9cd294e1aef0e628`。游戏内按档案准备/可选导入、跳过与恢复、自动保存/检查/切换、简洁连接面板和旧 R3 问题修正已进入候选。**未完成本批验收，不能标记 PASS。**

第二轮 14 命令中 13 通过：Go 371 顶层/765 含子项通过、1 live SKIP；C# 247，UI/流程 83，两端构建与静态检查通过。唯一失败为 `tools/test_local_admin_ui.js:28` 模拟 DOM 未创建 recall 节点；后续 Recall 断言未运行。按 DEVELOPMENT_WORKFLOW 的两轮上限冻结，未第三轮修补。

R3-1/R3-2 已有代码修正，独立关闭结论仍待审查；R3-2 动态回归还未通过。未做 Unity/真实 API/原玩家数据验收，未安装、推送或发布。CP14-9 未开始。详情见 `docs/CP14_R0_R6_IMPLEMENTATION.md`，证据 `C:/Users/32920/Documents/Codex/2026-09-27/yao/outputs/cp14-r0-r6`。下一步由用户决定并发起 Astra 极高只读审查/继续授权。

以下旧“最新包”“R3 未修”“等待宽度确认”等段落按历史保留，不能覆盖本节当前状态。

---

## 设置横向溢出修订（2026-09-27；最新补充）

用户在上一候选实际游戏中报告：展开设置后名称移出视口。已定位新表单漏掉旧输入框的最小宽度约束，长 Key（含星号）撑大父级，导致按钮居中点移出视口。AIChat `594607168b0dcfc295fb9aaf3763379e3df5ac86` 恢复输入收缩，并将连接页长标签/状态/按钮/开关改为换行布局；SPP 运行源码仍为 `e2671695ae6a6ca9c883cc8434230690142497cb`。

用户明确提出回归修复后追加一轮本地验证，8 命令全通过：247 项纯逻辑、70 项 UI 契约（新增 28 项，含旧问题负对照及多宽度/字号/模式/显示状态）、接线检查与 Release DLL。编译 0 错误 / 51 既有警告；未触发第二轮。150 个跟踪文件与固定源码导出在验证前后核对一致。布局替身不是 Unity 原生画面验收；新 DLL 未安装进游戏，真实服务未调用。原两轮历史保留。

最新 DLL 修复包：`C:/Users/32920/Documents/Codex/2026-09-27/yao/outputs/AIChat_CP14_SettingsWidthFix_20260927.zip`；SHA-256 `9fe40e962c72539fc44f9dc501a995e1258f363fdde06fbe187e5a7e2141abcc`。DLL SHA-256 `bc69e86830c421758038d67e9b780d689bbef848f46720ec8a119daa7a8fe963`。只替换原 AIChat.dll，原 SPP/配置保持；说明在同目录「设置宽度修复说明.md」。旧完整包仍提供配套 SPP，但其中 AIChat.dll 已被本修复取代。证据：`C:/Users/32920/Documents/Codex/2026-09-27/yao/outputs/settings-width-review`。

当前等待原尺寸下的实际游戏确认，再按原计划独立复审（Astra / 极高建议）。R3-1/R3-2 未修，CP14-8 总门禁仍未通过，CP14-9 未开始。下文旧的“最新配对/42 项 UI”及文档轮次均按当时状态保留；准确文档 HEAD 见恢复索引 `D:/SatoneDev/research/cp14-final-polish/progress.json`。

---

以下为本次修订前的接管/阶段记录。

## CP14-8 最后阶段接管（2026-09-27；当前入口）

本聊天接管最终开发润色与进度留档。当前为 CP14-8 修订/独立复审/真实验收，CP14-9 未开始。最新已测配对 AIChat `6314050f5f99de9ad0b33eacee08d4ec4881b6f0` / SPP `e2671695ae6a6ca9c883cc8434230690142497cb`；统一「连接与模型」、互斥 OpenAI/DS、独立 Key 显示及手填模型已实现，第二轮本地验证通过（Go 366 顶层 / 756 含子项，1 live SKIP；C# 247，UI 42）。最新界面尚无独立审查或 Unity/真实服务 PASS。

R3-1 回执身份校验与 R3-2 Recall 旧结果残留均未修，原审查 CHANGES REQUIRED 继续保留。不要把下方较早的“尚未实现”“待第三次审查”当作当前事实。

最新测试包 `C:/Users/32920/Documents/Codex/2026-09-27/yao/outputs/SatoneMod_CP14_ProviderSettings_Test_20260927.zip`。完整源码、产物哈希、证据、剩余步骤、轮次与恢复边界见 [最后阶段接管记录](CP14_FINAL_HANDOFF.md)。本次仅文档记录，所有测试仍绑定上述代码 SHA；文档提交后的 HEAD 见 `D:/SatoneDev/research/cp14-final-polish/progress.json`。

---

以下为历史记录，恢复工作优先阅读上方当前接管入口。

## CP14-7/8 第二轮最终本地检查通过，等待独立审查与真实验收

最终 AIChat `bb175cc8e7df6a66a682a9ec578b726e61855052` 补强播放/字幕/动画子迭代器的 generation，第二轮五项 PASS（218 逻辑、29 UI/迭代器、资源接线、DLL、实际 EXE+C# 配对）。SPP 全量/EXE 仍引用第一轮源码 `5b2708b50f708b41aca2cca9d5da85944260e108`；第二轮 Go 驱动 HEAD `9c05552d92d5720b0a12d3ff101a10486f8b0397` 仅 Markdown 差异。7/8 额度均两轮用完，6.2 一轮；[完整证据](CP14_8_LOCAL_VALIDATION.md) / [Astra 提示词](CP14_6_2_8_ASTRA_REVIEW_PROMPT.md)。8 总门禁仍未 PASS，不进入 9。下一步 Astra 极高独立审查，真实 API/游戏仍未授权。下文为首轮及更早历史。

## CP14-6.2 / 7 / 8 第一轮记录（后续修订见上）

6.2 第一轮八项、7 第一轮十二项、8 第一轮十三项本地 CI 均 PASS，三个第二轮均未触发。最后实测源码 SPP `5b2708b50f708b41aca2cca9d5da85944260e108` / AIChat `886cb999d86221f5d7def2465e128271abfc8ad7`；[准确证据](CP14_8_LOCAL_VALIDATION.md)。实际 EXE+C# 合成跨端通过；不是 Unity/真实 DS。旧手动 Memory/Recall/dashboard 管理差距尚在，CP14-8 **总门禁未 PASS**，未进入 9。下一步按原流程 Astra 极高独立审查：[可发送提示词](CP14_6_2_8_ASTRA_REVIEW_PROMPT.md)。真实 API/游戏分别需明确授权，未部署/推送/远端 CI/发版。下文保留历史进度。

## CP14-6.2 第一轮本地 PASS（优先于历史记录）

6.1 第二轮独立 PASS 已核对，用户放行继续。6.2 已测源码 `0f79cdf7edad652aae3944e0774ea54c9083aba6` 八项本地 CI PASS（342 顶层 / 709 含子测试，1 live SKIP），第二轮未触发；[完整验证](CP14_6_2_LOCAL_VALIDATION.md)。继续 7，使用用户指定 Sol 极高。尚无新客户端、真实 DS 或 Unity 验收，未推送/发布。

## CP14-6.1 修复交接：待第二轮独立审查（2026-09-27）

修订源码 `d7e8c39c329c1a7fb5872536618ac89277422e1f` 的一次授权追加验证通过：**333 顶层 / 691 含子测试 PASS，0 FAIL，1 个真实 OpenAI 用例 SKIP**。 原审查 R6.1-1 合法关系 fixture 与 R6.1-2 非法可选 usage 丢弃有效回复均已修订；八项本地检查及一项跨版本 WAL 定向检查通过，详见 [修订、授权与准确证据](CP14_6_1_REVIEW_FIX.md)。AIChat 保持 `9ef740d010e4a5e8b19d88265a499a7392f2a485`，未重跑 .NET。

本次由原审查对话按用户新授权修复，不能自称第二轮独立 PASS。原两轮和原 FAIL 保持不变；用户将把结果交第二轮独立审查。未推进 6.2/7/8，未真实服务/游戏验收，未推送、远端 CI、合并或发布。下一阶段 6.2 原推荐 Sol 极高，须独立门禁放行。下文保留历史停点。

## 2026-09-27 CP14-6.1 最新停点（优先于下文）

CP14-6.1 第二候选 `a0650074234e0830f2a52e9f604cca0261343d2f` 的第二轮 Go/checkptr 在同一新增关系投影 fixture 失败，其余六项通过。遵用户两轮规则停止，不进入 6.2/7/8。详见 [交接与证据](CP14_6_1_REVIEW_HANDOFF.md) / [Astra 提示词](CP14_6_1_ASTRA_PROMPT.md)。后文为历史阶段记录；CP14-3/4/5 原 PASS 保留。

## 修复后最新门禁（2026-09-27）

修复源码 `b3d929da2f9790c4648d097e88d5ff637bb9d2b0` 的追加本地验证通过：319 顶层 / 543 含子测试 PASS，1 个真实 OpenAI 用例跳过。格式、全量 Go/ASR fixture、vet、CP14 checkptr、Windows 构建、实际 EXE 迁移/重启及 Linux 交叉构建共七项通过。 CP14-3、4、5 修复后门禁均 PASS，放行 CP14-6 开发入口。原独立审查曾因三项问题拒绝放行；本次由同一审查对话按用户追加要求修复并定向复核，不冒充另一位独立 reviewer 的新审查。 [逐项结果](CP14_3_5_REVIEW_FIX_VALIDATION_2026-09-27.md)。

没有真实 DS、玩家资料或 Unity 验收；CP14-6/7 代码尚未实现，不能宣称 DS 首包通过。未推送、远端 CI、合并或发布。原两轮与原审查证据保持不变；此次为用户要求继续后的追加验证，未重置轮次。 下一阶段 CP14-6 切换操作；按 v1.1 原推荐 Sol 极高（xhigh），关注全局操作幂等、epoch、取消、旧凭据引用、worker 结算及播放等待，不自动修改模型设置。

## CP14-5 当前结果（2026-09-27）

停写复制迁移、旧进程/Recall worker 写入排除、清单/备份、未知历史与 pending 隔离、fresh 档案及原子激活恢复已实现。SPP 已测源码 `f4706302a2c39454c77ec6c6a79299e2927cdb0e` 第二轮九项本地 CI 全 PASS：313 顶层 / 520 含子测试、1 live SKIP；Windows ACL、真实进程退出、WAL 故障、迁移/旧/本地 EXE 回归通过。详见 [实现与限制](CP14_5_MIGRATION.md) / [两轮证据](CP14_5_LOCAL_VALIDATION_2026-09-27.md)。这是显式停机维护 CLI，不能运行时热迁移；大档案容量和真实玩家资料尚未验收。

**当前停在 CP14-5，待用户用 Astra 极高独立审查 3～5**：[审查包](CP14_3_5_ASTRA_REVIEW.md)。AIChat 运行代码未变；6/7 的选择/UI/语音接线尚未实施。未触发第三轮、远端 CI、推送、合并或发布。通过后下一阶段 6 原推荐 Sol 极高（xhigh）。下文“未开始 5”等是较早阶段记录。

剩余阶段的依赖、独立审查/实机边界、连续执行建议、耗时与中断恢复要求见 [执行评估](CP14_REMAINING_EXECUTION_PLAN.md)。本次评估未开始 CP14-5。

## CP14-4 当前结果（2026-09-27）

本地生成/Repair/Fresh、冻结上下文及 Archive/Recall/Relationship/Auto Memory 已接入。候选 `247e7ad4aee262d981e3b7b0581364cd8c27fe89` 第二轮九项本地 CI 全 PASS：291 顶层 / 470 含子测试 PASS、1 live SKIP；Windows 凭据/私有目录 ACL、checkptr/vet、构建、新旧 EXE 实际重启、真实 Python Recall 和 Linux 交叉编译通过。首轮后修复模型结果写入前失败时 running 任务未单独触发启动恢复的遗漏；没有第三轮。

见 [实现边界](CP14_4_PIPELINE.md) 与 [两轮准确 SHA/日志](CP14_4_LOCAL_VALIDATION_2026-09-27.md)。这是本地实现门禁，不是独立 Astra 或真实服务/游戏 PASS。本阶段无用户激活/迁移/切换界面；无 local_v1 的安装继续旧云端，有本地恢复故障时不回退云端。AIChat 运行源码不变，既有测试仍绑定 f56db651。

下一阶段 **CP14-5 / GPT-6 Sol 极高（xhigh）**：复制迁移、所有旧写入者屏障、激活恢复。沿用 v1.1 阶段原推荐，用户可调整；CP14-5 完成后建议独立 Astra 极高审查，由用户发起。本轮未开始 CP14-5、未推送、未运行远端 CI、未合并或发布。下面的 CP14-3“未接入聊天”是历史状态。

## CP14-3 历史结果（2026-09-27）

用户明确开始后，本地存储与持久事务候选已实现，第二轮本地 CI 在 `7e74bf38364f2a36a9adf73d160965333b6ceef8` 全部通过。273 顶层 / 440 含子测试 PASS、1 live SKIP；Windows ACL/checkptr/vet、构建、EXE 回归及 Linux 交叉编译 PASS。全局日志将请求登记与 prepared/accepted 绑定在同一提交；冻结连接、摘要覆盖、未知副作用、屏障/worker 恢复均有回归。第一轮后自审补修完整日志末尾丢失的锚点核对，未进入第三轮。详见 [实现说明](CP14_3_LOCAL_STORE.md) 与 [两轮逐项 SHA](CP14_3_LOCAL_VALIDATION_2026-09-27.md)。

尚未将新存储接入聊天或旧写入者，没有迁移、真实 API/游戏验收或本阶段独立 PASS。AIChat 运行源码不变。下一阶段 **CP14-4 / GPT-6 Sol 极高（xhigh）**，沿用 v1.1 原推荐，用户可调整；本轮未开始 CP14-4。下面保留 CP14-1/2 收尾时的状态，不覆盖此更新。

后续每步按 [两轮本地 CI 与模型建议规则](DEVELOPMENT_WORKFLOW.md) 执行。用户已明确只需本地完成 CI，不补跑远端 CI。CP14-1 设计门禁与 CP14-2 代码独立复审均 PASS；CP14-2 本地验证已完成。CP14-3 已满足进入条件，尚未开始。阶段收尾沿用事先开发档案中该阶段末尾的推荐档位。

2026-09-27 用户交付的 PASS 适用于本地 SPP `5b0d6eafa866539f0ea09eb654b5146b1291135c` / AIChat `ca729ff41510f82d0facb922a7d36fd718f68125`，不适用于远端旧候选。D1–D3/C1–C4 全部通过，证据边界见 [独立复审归档](CP14_REVIEW_PASS_2026-09-27.md)。下一阶段 CP14-3 推荐 **GPT-6 Sol / 极高（xhigh）**，沿用此前对话摘录的 v1.1 原推荐；风险仍为存储原子性、请求幂等和崩溃恢复。原测试 SHA 保持不变，后续文档提交不冒充新 HEAD 重跑。

## 2026-09-27 本机接管的最新状态

本轮在已有 CP14 分支提交修订，准确测试提交 SPP `5804a42d81ec2a15baa3d0da9a3e70977746eacd` / AIChat `f56db651a65d3eb54e956cdd1100f92f44e4802d`。本机全量 Go 259 顶层 PASS（含子测试 405 PASS，1 个 live OpenAI 跳过）、Windows DACL/checkptr/vet、Windows EXE 与隔离启动重启、AIChat 201 逻辑 + 23 UI 测试、UI 接线和 DLL 构建通过。记录了原候选 Windows 测试失败及双连接并发结果丢失的复现和修订。

完整 D1–D3、C1–C4 对照、命令、SHA、日志与限制见 [CP14 本机验证](CP14_LOCAL_VALIDATION_2026-09-27.md)。该执行记录是实现方验证，之后已取得上述独立 PASS；未推送或运行新远端 CI，CP14-3 核心存储未开始。下文保留此前云端阶段记录，其中“不完整本机工具链/未执行/CHANGES REQUIRED”均为历史状态，不能覆盖本次本地验证及独立复审结论。

## 之前的阶段记录

更新：2026-09-27 JST。**CP14-0 基线核对完成；CP14-1 独立评审结论为 `CHANGES REQUIRED`，设计已按 D1–D3 修订、待复审；CP14-2 独立代码审查结论为 `CHANGES REQUIRED`，C1–C4 修订候选尚待准确提交验证。** 旧 OpenAI 聊天链路仍是运行真值；未接入 DS 聊天、迁移、本地档案或切换。CP14-3 至 CP14-9 尚未开始；CP15 不属于 DS 首包；CP16 Ollama 排在 CP15 后。

## 两仓当前实现基线（保留初次核对记录）

| 项目 | `develop` SHA | 运行版本 | 基线 CI | CP14 文档分支 |
| --- | --- | --- | --- | --- |
| SPP | `916c61a71973f825266be7140d84c45afbd6bcaa` | `5.8.23` | [go-tests/Windows clean install/package PASS](https://github.com/Scaleph-Enkidu/SatonePromptProxy/actions/runs/36246727033)；[build PASS](https://github.com/Scaleph-Enkidu/SatonePromptProxy/actions/runs/36246727000) | `feature/cp14-multi-api-v1-1`，从 develop 创建 |
| AIChat | `90a16842ffa86374fc05a4861ebfbb58286e8313` | `1.16.15` | [正式版 CI PASS](https://github.com/Scaleph-Enkidu/SatoneAIChat_Remake/actions/runs/36264179180) | `feature/cp14-multi-api-v1-1`，已将发布源码合并入原文档分支 |

本 CP14 文档工作没有修改 `main` 或 `source-history`；其后 AIChat 1.16.15 独立正式发布，`main`/`develop`/`AIChat-v1.16.15` tag 都指向 `90a16842ffa86374fc05a4861ebfbb58286e8313`。本次仓库检查未发现 `multi` 命名分支或相应 provider PR；不能据此证明没有其他未推送的工作。本地只有上传计划，没有旧源码工作树，也无 GitHub CLI 认证，因此本次通过 GitHub 连接器读取私库与创建独立文档分支；没有执行本机源码编译，基线测试结论只来自上述远端 Actions。

基线校准：最初 CP14-0 使用 AIChat `aeaa1b33598d68ead0b3d1353b3793e5df399cc2` / 1.16.14，后来 [AIChat 1.16.15 正式 Release](https://github.com/Scaleph-Enkidu/SatoneAIChat_Remake/releases/tag/AIChat-v1.16.15) 发布，修复控制台 UI 纹理反复创建；修复源码与 `AIChat.UI.Tests` 已合入 CP14 同名分支，先前文档历史没有改写。其发布说明配对 SPP **5.8.22**；此前 SPP 5.8.23 分发包配对 AIChat **1.16.14**。所以 **1.16.15 + 5.8.23 是两仓开发源码组合，不是有记录的正式配对实机验收**。罕见长时卡死原因仍待长期观察；CP14-7 必须保留纹理缓存修复和专项测试。SPP 的旧 ASR provenance 修复分支与 CP14 职责不同。

## CP14-0 核查

- 已读两仓 `AI_HANDOFF.md`、Known Issues、Design Decisions、Maintenance、Testing、Architecture 及相关 SPP 领域文件；定位 `main.go`、`provider.go`、`fresh.go`、`auto_memory_jobs.go`、`relationship_queue.go`、`persona_api.go`、`turn.go`、`conversation_turn.go`、AIChat `AIMod.cs`、`SatonePromptProxyIntegration.cs`、`SatoneConversation.cs`。
- 已核对版本和 CI。SPP 的现有 CI 用根目录全部 Go 文件调用 `gofmt`、`go test`，Windows 构建非测试 Go 文件并做 clean install/package；AIChat 1.16.15 用 `dotnet run --project AIChat.Tests/AIChat.Tests.csproj -c Release`、`python3 tools/check_ui_resources.py`、`dotnet run --project AIChat.UI.Tests/AIChat.UI.Tests.csproj -c Release`、`dotnet build -c Release`、包与 SHA。新文件必须进入同一测试/打包流程。
- 当前协议确认：AIChat 对 SPP 只传最新 user；SPP 使用 OpenAI Responses + Persistent Conversations；Memory/Persona/Relationship 绑定远端 developer item；关系 FIFO、AcceptedTurn 后副作用、失败轮 rollback 有已形成的门禁。不能把“SPP 对 AIChat 暴露 `/v1/chat/completions`”误认为它已经能向 DS 发 Chat Completions。
- 现有问题继续跟踪：SPP 5.8.23 压缩实机边界、协议超限；AIChat 1.16.15 对罕见长期卡死的根因仍未完全证实，以及 VAD/剧情/长回复风险。CP14 未修复这些事项。

## CP14-1 审查对象及未决项

审查稿：[`MULTI_PROVIDER_PLAN.md`](MULTI_PROVIDER_PLAN.md)；验证表：[`MULTI_PROVIDER_TEST_MATRIX.md`](MULTI_PROVIDER_TEST_MATRIX.md)。计划明确三维分离、secret revision、stateless 本地上下文、AcceptedTurn 与迁移、AIChat 播放确认、OpenAI 回返路径、接口拟定。内部旧 D001 的替代尚为**提议**；评审通过并落地时才更新正式决策和架构文件。

建议独立审查重点：

1. 跨来源 Key 与旧 `lastAuth`、后台补发的消除范围；凭据旧 revision 如何在重启后安全恢复。
2. 旧云端近期 item 与 Archive 的差距、未完成 pending、同 response ID 的迁移与 Recall 键转换。
3. 本地 `accepted` 与四项副作用 receipt 的顺序，整轮朗读被打断但 SPP 已接受全文的语义。
4. 切换操作幂等、玩家三档案与两个后端、A→B→C/重启/旧回调如何维持隔离。
5. 只有 Chat Completions 的中转是否在聊天、Repair、Fresh、压缩、关系以及 Persona 重新加载中完全不触发专有 API。

独立审查输出需要 `PASS` 或 `CHANGES REQUIRED`、严重性、文件/行、复现、影响与关闭依据。独立评审已给出 `CHANGES REQUIRED`，本分支方案已针对 D1 生效连接不可变版本、D2 聊天请求幂等 ID、D3 迁移统一写入屏障修订；**这不是独立复审 PASS，不能开始 CP14-3 核心存储或迁移**。当前只修订 CP14-2 的隔离实现并等待准确提交的构建与复审。

## 检查点、提交与验证记录

| 检查点 | 职责 | 状态 | 当前证据/遗留 |
| --- | --- | --- | --- |
| CP14-0 | 基线与分支 | 完成读取和独立分支建立 | 上述 SHA/Actions；没有在本地重复跑基线；文档分支提交 SHA 见 Git 历史 |
| CP14-1 | 连接/接口/本地档案方案 | 独立评审 `CHANGES REQUIRED`；D1–D3 修订待复审 | 计划与测试矩阵；无功能代码、无版本包、无真实 DS 请求 |
| CP14-2 | 连接配置、凭据隔离、显式连接测试、通用 Chat Completions 适配器 | 独立审查 `CHANGES REQUIRED`；修订待验证；旧代码提交 `bc4a47f24e4093aed8c35e8d43a43479cec0cde8` 的 PR CI 已通过 | 新文件 `connections.go`、`chat_completions_provider.go`、`connections_test.go`；未接入旧 chatHandler，未进行真实 DS 请求；本机缺少完整 Go 标准库，只完成 gofmt/解析检查；[source build PASS](https://github.com/Scaleph-Enkidu/SatonePromptProxy/actions/runs/36266083975)、[go-tests / Windows clean install / candidate package PASS](https://github.com/Scaleph-Enkidu/SatonePromptProxy/actions/runs/36266083981) |
| CP14-3～9 | 本地档案、聊天集成、迁移、游戏验收与发布 | 未开始 | 不能提前标为支持 |
| CP15-0～3 | Claude/Gemini 后续 | 未开始 | 不阻塞 DS 首包 |
| CP16-0～5 | Ollama 本地推理与两仓配对 | 仅新增后置规划 | 优先本机 Chat Completions；依赖 CP14 本地档案/安全切换；不阻塞 DS 首包或 CP15 |

文档分支的每次提交以 GitHub 提交记录为准；**CP14 专属**版本、配对 ZIP、产物 SHA256、真实中转及游戏实机记录均为**无**。AIChat 1.16.15 的独立正式包不等于 CP14 产物。功能分支代码提交前继续复核两仓 `develop` 是否更新。完成各检查点后追加：计划版本、职责、两库 branch/HEAD、测试命令/结果、CI run、审查、产物 SHA、阻塞、工作树/推送状态。

### CP14-2 验证记录（2026-09-27 JST）

- 代码 SHA `bc4a47f24e4093aed8c35e8d43a43479cec0cde8`；草稿 [PR #14](https://github.com/Scaleph-Enkidu/SatonePromptProxy/pull/14)；[source build PASS](https://github.com/Scaleph-Enkidu/SatonePromptProxy/actions/runs/36266083975)；[go-tests / Windows clean install / candidate package PASS](https://github.com/Scaleph-Enkidu/SatonePromptProxy/actions/runs/36266083981)。Linux `go-tests` 跑根目录全部 Go 文件，Windows clean install 与候选包工作流通过；本机只有不完整 Go 工具链，未谎称本机 go test。自动用例均为受控 mock，不含真实 Key 或玩家数据。
- 通过的是连接层和非流式通用 Chat Completions 单次请求能力，显式连接测试最多标 `reachable`；旧 `/v1/chat/completions` 仍只走 OpenAI Responses + Conversations。CP14-1 独立审查、本地事件存储、全任务生成、迁移、AIChat UI、真实 DS/中转与实机测试未完成。不得据此发布或宣称 DS 已受支持。

### CP14-2 补强与当前验证阻塞（2026-09-27 JST）

- 本次功能分支代码提交 [`7426fbe`](https://github.com/Scaleph-Enkidu/SatonePromptProxy/commit/7426fbe6a85bfc606d6a062ecefb02b8de5f29c5)：连接测试满 64 条后只淘汰已完成记录；状态区分 `reachable` 与 `verification_persisted`；配置变更或验证写盘失败不冒充持久验证；新增对应模拟服务回归测试，修正 API 文档示例。旧云端配置目前只有脱敏只读展示，Key/历史导入属于 CP14-5。
- 本地 `gofmt -l` 对全部变更 Go 文件为空，`gofmt` 解析成功；工作区缺少完整 Go 标准库，无法在本机执行 `go test`。新提交的 [source build](https://github.com/Scaleph-Enkidu/SatonePromptProxy/actions/runs/36267439974) 和 [portable CI](https://github.com/Scaleph-Enkidu/SatonePromptProxy/actions/runs/36267439954) 的作业均在 runner 分配前失败，`runner_id=0`、`steps=0`；重试 source build 仍同样失败，原因未得到可用诊断。**以前 `bc4a47f` 的 PASS 只适用于旧代码；新提交不能标成 CI PASS 或 CP14-2 已经完整验证。**
- 完成门禁：GitHub Actions 可运行后在本提交或其后继的同代码 SHA 通过 `go test`、Windows clean install 和 source build；CP14-1 独立架构审查仍是 CP14-3 核心本地存储开始前的门禁。没有真实 DS Key/游戏验收，不发布 CP14 包。

### 独立评审及本次修订记录（2026-09-27 JST）

用户转交的独立评审对 CP14-1 与 CP14-2 均给出 `CHANGES REQUIRED`；评审没有提交到 GitHub PR 评论。设计 P1：D1 活跃连接必须绑定不可变配置快照；D2 AIChat 发送前持久生成 `chat_request_id` 并由 SPP 以档案+内容摘要幂等登记；D3 迁移在激活前须有统一旧写入屏障、来源增量核验及 worker 隔离。`MULTI_PROVIDER_PLAN.md` 已修订这三条，仍须原独立审查者复审；**未获 PASS 前不启动 CP14-3 核心本地档案实现**。

代码发现：C1 Windows `Chmod(0600)` 不提供凭据 DACL 隔离；C2 失败复测不持久；C3 探测请求省略 `max_tokens`；C4 连接 ID `tests` 与状态路由冲突。修订候选使用 Windows 受保护 DACL 创建临时文件并加固既有凭据文件、先持久标记探测进行中并清除旧可达证据，再持久记录完成/失败及历史成功；显式探测上限 128；`tests` 的 POST 测试先于 GET 状态分派。加入模拟回归和 Windows DACL 检查，并修改工作流按包筛选平台源码，在 Windows CI 运行权限测试。以上是变更目标，不能在 CI 无实际步骤的情况下写成已通过。

修订前的 `7426fbe` 和文档 HEAD `1d06c8e` 均无新代码 CI PASS；此前 `bc4a47f` 的 PASS 仅覆盖旧代码。更新后的准确提交 SHA 与 CI 结果需要另记；Windows 实际 ACL、Go 单测、source build 和旧 OpenAI 路径运行回归仍待核实。SPP 与 AIChat `develop/main` 未修改、未发布 CP14 包。

### 修订提交与 CI（2026-09-27 JST）

SPP 修订代码与设计提交 [`213a027`](https://github.com/Scaleph-Enkidu/SatonePromptProxy/commit/213a027dc847fc4bfe8a37925390e9e9dbc00bc1)；AIChat 对接契约文档提交 [`7fbc42b`](https://github.com/Scaleph-Enkidu/SatoneAIChat_Remake/commit/7fbc42b967cde4c0d119baac80f80adfa7011374)。本机针对修改的 5 个 Go 文件 `gofmt -l` 为空且解析成功；工作区缺少 Go 标准库，未运行 `go test`。新提交的 [source build](https://github.com/Scaleph-Enkidu/SatonePromptProxy/actions/runs/36269013812) 和 [portable validation](https://github.com/Scaleph-Enkidu/SatonePromptProxy/actions/runs/36269013834) 分别在 `build`、`go-tests`、`windows-clean-install` 作业的 `runner_id=0` / `steps=0` 时失败；`package-candidate` 跳过。这是 CI 执行基础设施阻塞，不是编译/测试失败。Windows ACL 尚未获得动态验证；新代码不能记为通过。后续应在此代码 SHA 或相同代码的新 HEAD 上获得实际执行的 Linux 单测、Windows ACL 单测、构建和旧 OpenAI 回归；独立复审另需对 D1–D3 和 C1–C4 给出结论。

### 修订候选的实现者自我复审（2026-09-27 JST）

发现并修复了一个确定的测试错误：`TestCP14ReachableProbeDoesNotVerifyChangedConfiguration` 仍使用启动探测前的全局配置 revision；探测现会先持久记录 `running` 并递增 revision，因此旧测试在修改配置时必然收到 409，无法验证目标竞态。复审也发现 Windows 测试只用 `Chmod`，没有建立真正宽松的旧文件 DACL；现用受控测试文件模拟 `Everyone` 访问、检查启动收紧，额外校验写入前临时文件 DACL。生产代码在写任何 Key 前读回受保护 DACL，不支持 ACL 的文件系统会拒绝保存。补充失败结果写盘故障后重启，以及管理 JSON 超过 32 KiB 仍被旧 LimitReader 接受的回归；后者改用 `MaxBytesReader`。

这是修订候选的**实现者自审与静态推理**，不能取代独立复审，也不能冒充 Linux/Windows 运行测试。具体后续代码提交 SHA、Actions runner/steps 和结果应另记；CP14-3 门禁继续关闭。

### 自审修正后的代码与执行证据（2026-09-27 JST）

测试与请求边界修正提交 [`9140acd`](https://github.com/Scaleph-Enkidu/SatonePromptProxy/commit/9140acd821b057294f5603564f036790a2d85994)；Windows 原生调用缓冲区存活补丁 [`b8fd472`](https://github.com/Scaleph-Enkidu/SatonePromptProxy/commit/b8fd4721cfc1da772c7f69bb5d1191a05233932b) 为最新代码 SHA。修订的 Go 文件 `gofmt -l` 为空。再次尝试本地 `GO111MODULE=off go test .`，因 GOROOT 缺少 `runtime`、`fmt`、`syscall` 等 Go 标准库而在启动前失败；没有编译/单测结论。

最新代码 `b8fd472` 的 [source build](https://github.com/Scaleph-Enkidu/SatonePromptProxy/actions/runs/36269871482) 和 [portable validation](https://github.com/Scaleph-Enkidu/SatonePromptProxy/actions/runs/36269871513) 均在 `runner_id=0`、`steps=0` 结束；`go-tests`、Windows DACL 用例与 clean install 未执行。`9140acd` 的两条 Actions run `36269776805` / `36269776836` 也相同。代码正确性、Windows 权限与旧 OpenAI 运行回归仍待真实执行；实现者自审不能替代独立复审，CP14-3 仍不放行。
