#!/usr/bin/env python3
# SatonePromptProxy v5 local recall worker.
# Uses SQLite for local archive indexing and optionally intfloat/multilingual-e5-small for local semantic embeddings.
import argparse, base64, json, math, os, re, sqlite3, struct, sys, traceback
from pathlib import Path

try:
    sys.stdin.reconfigure(encoding="utf-8")
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

MODEL_ID_DEFAULT = "intfloat/multilingual-e5-small"


def eprint(*a):
    print(*a, file=sys.stderr, flush=True)


def open_db(path):
    con = sqlite3.connect(path)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA synchronous=NORMAL")
    con.execute("""CREATE TABLE IF NOT EXISTS exchanges(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      exchange_id TEXT UNIQUE,
      timestamp TEXT,
      conversation_id TEXT,
      user_text TEXT,
      assistant_text TEXT,
      full_text TEXT,
      embedding BLOB,
      dim INTEGER DEFAULT 0
    )""")
    # trigram FTS is ideal for Chinese/Japanese substring matching. Fall back if unavailable.
    try:
        con.execute("CREATE VIRTUAL TABLE IF NOT EXISTS exchanges_fts USING fts5(exchange_id UNINDEXED, full_text, tokenize='trigram')")
        fts_mode = "trigram"
    except Exception:
        con.execute("CREATE VIRTUAL TABLE IF NOT EXISTS exchanges_fts USING fts5(exchange_id UNINDEXED, full_text, tokenize='unicode61')")
        fts_mode = "unicode61"
    con.commit()
    return con, fts_mode


class Worker:
    def __init__(self, db_path, model_dir, model_id, device="cpu"):
        self.db_path = db_path
        self.model_dir = Path(model_dir)
        self.model_id = model_id
        self.device = device
        self.con, self.fts_mode = open_db(db_path)
        self.tokenizer = None
        self.model = None
        self.torch = None
        self.np = None
        self.vector_ids = []
        self.matrix = None
        self.dim = 0
        self.last_error = ""
        self._load_existing_vectors()
        if self.model_installed():
            try:
                self.load_model()
            except Exception as ex:
                self.last_error = str(ex)
                eprint("Embedding model exists but could not be loaded:", ex)

    def model_installed(self):
        p = self.model_dir
        return (p / "config.json").exists() and ((p / "model.safetensors").exists() or (p / "pytorch_model.bin").exists())

    def _load_existing_vectors(self):
        try:
            import numpy as np
            self.np = np
        except Exception:
            return
        rows = self.con.execute("SELECT id,embedding,dim FROM exchanges WHERE embedding IS NOT NULL AND dim>0 ORDER BY id").fetchall()
        vecs, ids = [], []
        for rid, blob, dim in rows:
            try:
                v = np.frombuffer(blob, dtype='<f4')
                if len(v) == dim and dim > 0:
                    vecs.append(v.copy()); ids.append(rid)
            except Exception:
                pass
        if vecs:
            self.matrix = np.vstack(vecs).astype('float32', copy=False)
            self.vector_ids = ids
            self.dim = self.matrix.shape[1]

    def load_model(self):
        if not self.model_installed():
            raise RuntimeError("embedding model is not installed")
        import torch
        import numpy as np
        from transformers import AutoTokenizer, AutoModel
        self.torch, self.np = torch, np
        try:
            torch.set_num_threads(max(1, min(8, (os.cpu_count() or 4) // 2)))
        except Exception:
            pass
        self.tokenizer = AutoTokenizer.from_pretrained(str(self.model_dir), local_files_only=True)
        self.model = AutoModel.from_pretrained(str(self.model_dir), local_files_only=True)
        self.model.eval()
        self.model.to("cpu")  # deliberately keep the recall model off the GPU used by GPT-SoVITS/Whisper
        self.last_error = ""
        return True

    def encode(self, texts, kind):
        if self.model is None:
            raise RuntimeError("embedding model not loaded")
        prefix = "query: " if kind == "query" else "passage: "
        arr = [prefix + (t or "") for t in texts]
        tok = self.tokenizer(arr, max_length=512, padding=True, truncation=True, return_tensors='pt')
        with self.torch.no_grad():
            out = self.model(**tok)
            mask = tok['attention_mask'].unsqueeze(-1).bool()
            hidden = out.last_hidden_state.masked_fill(~mask, 0.0)
            emb = hidden.sum(dim=1) / tok['attention_mask'].sum(dim=1, keepdim=True).clamp(min=1)
            emb = self.torch.nn.functional.normalize(emb, p=2, dim=1)
        return emb.cpu().numpy().astype('float32')

    def status(self):
        n = self.con.execute("SELECT COUNT(*) FROM exchanges").fetchone()[0]
        ne = self.con.execute("SELECT COUNT(*) FROM exchanges WHERE embedding IS NOT NULL").fetchone()[0]
        return {
            "ok": True, "db": self.db_path, "fts_mode": self.fts_mode,
            "exchanges": n, "embedded_exchanges": ne,
            "model_id": self.model_id, "model_dir": str(self.model_dir),
            "model_installed": self.model_installed(), "model_loaded": self.model is not None,
            "dimension": self.dim, "last_error": self.last_error,
        }

    def add_exchange(self, obj):
        exid = obj.get('exchange_id') or ''
        ts = obj.get('timestamp') or ''
        conv = obj.get('conversation_id') or ''
        user = obj.get('user_text') or ''
        assistant = obj.get('assistant_text') or ''
        full = obj.get('full_text') or ("Player: " + user + "\nSatone: " + assistant)
        blob, dim = None, 0
        if self.model is not None:
            try:
                v = self.encode([full], 'passage')[0]
                blob, dim = v.astype('<f4', copy=False).tobytes(), len(v)
            except Exception as ex:
                self.last_error = str(ex); eprint("Embedding add failed:", ex)
        self.con.execute("INSERT OR REPLACE INTO exchanges(exchange_id,timestamp,conversation_id,user_text,assistant_text,full_text,embedding,dim) VALUES(?,?,?,?,?,?,?,?)",
                         (exid, ts, conv, user, assistant, full, blob, dim))
        self.con.execute("DELETE FROM exchanges_fts WHERE exchange_id=?", (exid,))
        self.con.execute("INSERT INTO exchanges_fts(exchange_id,full_text) VALUES(?,?)", (exid, full))
        self.con.commit()
        # Refresh vector cache only for this row; replacement is uncommon, so reload for correctness.
        if blob is not None:
            self._reload_vectors()
        return {"ok": True, "exchange_id": exid, "embedded": blob is not None}

    def add_batch(self, items):
        items = items or []
        texts = [(it.get('full_text') or ("Player: "+(it.get('user_text') or '')+"\nSatone: "+(it.get('assistant_text') or ''))) for it in items]
        vectors = None
        if self.model is not None and texts:
            try:
                vectors = self.encode(texts, 'passage')
            except Exception as ex:
                self.last_error=str(ex); eprint("Embedding batch failed:", ex)
        for i,it in enumerate(items):
            exid=it.get('exchange_id') or ''; ts=it.get('timestamp') or ''; conv=it.get('conversation_id') or ''
            user=it.get('user_text') or ''; assistant=it.get('assistant_text') or ''; full=texts[i]
            blob,dim=None,0
            if vectors is not None:
                v=vectors[i]; blob=v.astype('<f4',copy=False).tobytes(); dim=len(v)
            self.con.execute("INSERT OR REPLACE INTO exchanges(exchange_id,timestamp,conversation_id,user_text,assistant_text,full_text,embedding,dim) VALUES(?,?,?,?,?,?,?,?)",(exid,ts,conv,user,assistant,full,blob,dim))
            self.con.execute("DELETE FROM exchanges_fts WHERE exchange_id=?",(exid,)); self.con.execute("INSERT INTO exchanges_fts(exchange_id,full_text) VALUES(?,?)",(exid,full))
        self.con.commit()
        if vectors is not None: self._reload_vectors()
        return {"ok":True,"count":len(items),"embedded":vectors is not None}

    def _reload_vectors(self):
        self.matrix = None; self.vector_ids = []; self.dim = 0
        self._load_existing_vectors()

    def _keyword(self, q, limit):
        q = (q or '').strip()
        if not q: return {}
        scores = {}
        stop = {'还记得','记得','之前','以前','上次','曾经','当时','那个','那次','前几天','前阵子','覚えて','前に','この前','前回','あの時','remember','before','last time','previously'}
        ascii_words = [w.lower() for w in re.findall(r"[A-Za-z0-9_\-]{2,}", q) if w.lower() not in stop]
        cjk_runs = re.findall(r"[\u3040-\u30ff\u3400-\u9fff]+", q)
        trigrams, bigrams = [], []
        for run in cjk_runs:
            for i in range(max(0,len(run)-2)):
                t=run[i:i+3]
                if t not in stop: trigrams.append(t)
            for i in range(max(0,len(run)-1)):
                t=run[i:i+2]
                if t not in stop: bigrams.append(t)
        # Prefer distinctive tail terms: long ASCII words and CJK ngrams.
        fts_terms = (ascii_words + trigrams)[-16:]
        try:
            if self.fts_mode == 'trigram' and fts_terms:
                match = " OR ".join('"'+t.replace('"','')+'"' for t in fts_terms)
                rows = self.con.execute("SELECT exchange_id,bm25(exchanges_fts) FROM exchanges_fts WHERE exchanges_fts MATCH ? ORDER BY bm25(exchanges_fts) LIMIT ?", (match, limit)).fetchall()
                for rank,(exid, bm) in enumerate(rows):
                    # bm25 magnitude is corpus dependent; rank contributes a stable local score.
                    scores[exid] = max(scores.get(exid,0.0), 0.78/(1.0+rank*0.10))
        except Exception:
            pass
        # CJK bigrams and short names are not searchable by trigram FTS; use indexed table LIKE as fallback.
        like_terms = (ascii_words + bigrams)[-12:]
        for term in like_terms:
            if len(term) < 2: continue
            try:
                rows = self.con.execute("SELECT exchange_id FROM exchanges WHERE full_text LIKE ? ORDER BY id DESC LIMIT ?", ('%'+term+'%', min(limit,12))).fetchall()
                for rank,(exid,) in enumerate(rows):
                    scores[exid] = max(scores.get(exid,0.0), 0.95/(1.0+rank*0.12))
            except Exception:
                pass
        return scores

    def search(self, query, top_k=3, candidate_limit=30):
        keyword = self._keyword(query, candidate_limit)
        semantic = {}
        semantic_ready = self.model is not None and self.matrix is not None and len(self.vector_ids) > 0
        if semantic_ready:
            try:
                qv = self.encode([query], 'query')[0]
                sims = self.matrix.dot(qv)
                k = min(candidate_limit, len(sims))
                if k > 0:
                    idx = self.np.argpartition(sims, -k)[-k:]
                    idx = idx[self.np.argsort(sims[idx])[::-1]]
                    for i in idx:
                        semantic[self.vector_ids[int(i)]] = float(sims[int(i)])
            except Exception as ex:
                semantic_ready = False; self.last_error = str(ex); eprint("Semantic search failed:", ex)
        # map exchange_id -> row id for keyword hits, and row ids -> data
        kw_by_id = {}
        for exid, sc in keyword.items():
            row = self.con.execute("SELECT id FROM exchanges WHERE exchange_id=?", (exid,)).fetchone()
            if row: kw_by_id[row[0]] = sc
        ids = set(semantic.keys()) | set(kw_by_id.keys())
        results = []
        for rid in ids:
            row = self.con.execute("SELECT exchange_id,timestamp,user_text,assistant_text,full_text FROM exchanges WHERE id=?", (rid,)).fetchone()
            if not row: continue
            sem = semantic.get(rid, 0.0)
            kw = kw_by_id.get(rid, 0.0)
            # E5 cosine scores are not calibrated probabilities; keep raw semantic score visible.
            if semantic_ready:
                combined = max(sem, 0.82*sem + 0.18*kw, 0.90*kw)
            else:
                combined = kw
            results.append({"exchange_id":row[0],"timestamp":row[1],"user_text":row[2],"assistant_text":row[3],"full_text":row[4],"semantic_score":sem,"keyword_score":kw,"score":combined})
        results.sort(key=lambda x:x['score'], reverse=True)
        return {"ok":True,"semantic_ready":semantic_ready,"results":results[:max(1,int(top_k))]}

    def reset_db(self):
        self.con.execute("DELETE FROM exchanges")
        self.con.execute("DELETE FROM exchanges_fts")
        self.con.commit(); self._reload_vectors()
        return {"ok": True}


def install_model(model_id, model_dir):
    from transformers import AutoTokenizer, AutoModel
    model_dir = Path(model_dir); model_dir.mkdir(parents=True, exist_ok=True)
    eprint("Downloading", model_id, "from Hugging Face...")
    tok = AutoTokenizer.from_pretrained(model_id)
    mdl = AutoModel.from_pretrained(model_id)
    tok.save_pretrained(str(model_dir))
    try:
        mdl.save_pretrained(str(model_dir), safe_serialization=True)
    except Exception:
        mdl.save_pretrained(str(model_dir))
    eprint("Saved local embedding model to", model_dir)


def acquire_writer_lease(db):
    # Shared with CP14 offline migration. Keep the descriptor alive until the
    # worker exits, even when the parent SPP process has already died.
    path = os.path.abspath(db) + '.writer.lock'
    os.makedirs(os.path.dirname(path), exist_ok=True)
    lease = open(path, 'a+b')
    try:
        if os.name == 'nt':
            import msvcrt
            lease.seek(0)
            msvcrt.locking(lease.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(lease.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BaseException:
        lease.close()
        raise
    return lease


def serve(args):
    lease = acquire_writer_lease(args.db)
    try:
        serve_locked(args)
    finally:
        lease.close()


def serve_locked(args):
    w = Worker(args.db, args.model_dir, args.model_id, args.device)
    eprint("Satone local recall worker ready; fts=", w.fts_mode, "model_loaded=", w.model is not None)
    for line in sys.stdin:
        line=line.strip()
        if not line: continue
        try:
            req=json.loads(line); cmd=req.get('cmd','')
            if cmd=='status': res=w.status()
            elif cmd=='add': res=w.add_exchange(req)
            elif cmd=='add_batch': res=w.add_batch(req.get('items',[]))
            elif cmd=='search': res=w.search(req.get('query',''), int(req.get('top_k',3)), int(req.get('candidate_limit',30)))
            elif cmd=='load_model': w.load_model(); res=w.status()
            elif cmd=='reset_db': res=w.reset_db()
            elif cmd=='shutdown': print(json.dumps({"ok":True}), flush=True); break
            else: res={"ok":False,"error":"unknown command: "+cmd}
        except Exception as ex:
            res={"ok":False,"error":str(ex)}
            eprint(traceback.format_exc())
        print(json.dumps(res, ensure_ascii=False, separators=(',',':')), flush=True)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--serve', action='store_true')
    ap.add_argument('--install', action='store_true')
    ap.add_argument('--db', default='SatoneRecall.db')
    ap.add_argument('--model-dir', default='models/multilingual-e5-small')
    ap.add_argument('--model-id', default=MODEL_ID_DEFAULT)
    ap.add_argument('--device', default='cpu')
    args=ap.parse_args()
    if args.install:
        install_model(args.model_id,args.model_dir); return
    serve(args)

if __name__=='__main__': main()
