# AIChat 1.17.0：CP23 文字优先与语音安装状态

<!-- Compatible pair: AIChat 1.17.0 + SatonePromptProxy 5.9.0 -->

正式配对 **SatonePromptProxy 5.9.0**。2026-10-01 用户确认测试完成并批准正式发布。本文说明本版功能、安装和验证边界；发布复用受测 DLL，不新增运行代码。完整资产、hash、证据边界与已知限制见 [CP23 版本与发布说明](CP23_RELEASE_20261001.md)。

## 本版范围

- 语音模块未安装 / 未启用时两个按钮深灰锁定并给出明确原因，文字输入和正常空闲抬头继续可用；加载中保持等待态，就绪后开放语音。
- 兼容旧 SPP 的可选安装状态字段，处理过期状态 / 重启后的重新确认；锁定控件不误触发可用状态的悬停反馈，原版剧情门禁保持优先。
- 文字聊天与 SPP 内置关键词回忆不要求 Python；配对 SPP 可独立追加 E5 int8 / ONNX 语义组件，UI 不把语义回忆作为语音前置。
- 超时 / 待结算提示引导查看 SPP 与日志，不再承诺一次重启必然补完记忆整理，也不要求重复发送待结算请求。
- 沿用已有聊天 Dock / 历史、原生字幕 / 动画、原版台词同步、剧情知识、三档 Memory、关系显示、Meta 演出、F8 / 持续通话与 TTS 单段预取。继承 CP21 稳定性修正；本次发布收尾不再改运行逻辑。

## 下载与安装

玩家下载公开配对主包 `SatoneMod_AIChat_1.17.0_SPP_5.9.0_Windows_x64.zip`（约11 MB），模型作为独立 `Satone_Semantic_E5_small_int8_ORT_1.30.0_Windows_x64.zip`（约94 MB）选装。AIChat 私库 `AIChat-v1.17.0` 附自身程序 ZIP，模型链接公开附件；权重不写源码 Git。

统一入口：[公开中文安装指南](https://github.com/Scaleph-Enkidu/SatonePromptProxy-SPP-_Releases/blob/main/docs/INSTALL.zh-CN.md)。四阶段为文字、ONNX 选装、聪音 TTS、玩家 ASR；文字不依赖后续阶段，ONNX 不是语音前置。AIChat DLL 替换游戏 `BepInEx/plugins` 中原插件，避免同插件保留两个 DLL；语义组件放 SPP EXE 目录。升级前停机并备份，保留模型、缓存、配置、Key、记忆、归档与声线，不用 example 覆盖玩家资料。整版本回退使用升级前配对程序与资料备份。

## 受测记录与限制

AIChat 受测构建源码 `c5da60b686766189c30ed7d69b71dab41098f6d2`，DLL SHA-256 `963d8b74ceaa9b54947f44b26cf624cdfe1f3d88d7ec4fee08d85137a5803050`。D3 第二轮六测试工程、生产构建、UI / provider 接线共九项通过；构建0错误/65警告。首轮旧接线检查FAIL与第二轮runner解析失败证据保留，不冒称没有失败或另开第三轮。

配对SPP源码 `5232d58882668fc1cf446db923fc8822fec2a810`，EXE SHA-256 `a05d6cdbd157152165a45b13046f95118d568f09bf1d6ea2a19c3761d56c421c`。D与分包证据的摘要和入口见 [CP23 版本与发布说明](CP23_RELEASE_20261001.md)。本地自动化仍绑定这些源码 / 实际候选包，不能转移为文档后HEAD的新全代码PASS；用户测试完成确认单独记录，不扩大成没有提供的逐项场景记录。

SPP大WAL冷启动仍慢：5万条合成WAL约495秒、整管线观察峰约944MB，350MB门禁只覆盖原worker+向量作用域。正式ZIP的大小与SHA以随附件发布的校验文件为准；各包独立核对CRC和逐文件hash，不能沿用旧候选ZIP hash。
