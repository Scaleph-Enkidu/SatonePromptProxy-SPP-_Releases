@echo off
chcp 65001 >nul
powershell -NoProfile -Command "try { Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:11435/backup' | ConvertTo-Json -Depth 5 } catch { Write-Host $_.Exception.Message }"
echo.
pause
