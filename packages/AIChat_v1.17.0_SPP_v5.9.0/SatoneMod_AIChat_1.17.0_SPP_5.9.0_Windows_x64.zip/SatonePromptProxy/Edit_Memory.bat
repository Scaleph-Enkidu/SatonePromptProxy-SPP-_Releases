@echo off
chcp 65001 >nul
rem local_v1 maintenance uses the WAL-backed dashboard and durable operation IDs.
powershell -NoProfile -Command "try { $s=Invoke-RestMethod -Uri 'http://127.0.0.1:11435/selection' -TimeoutSec 3; if ($s.backend -eq 'local_v1') { Start-Process 'http://127.0.0.1:11435/dashboard'; exit 20 } } catch {}"
if errorlevel 20 exit /b 0
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-RestMethod -Uri 'http://127.0.0.1:11435/profiles'; $p=$r.profiles | Where-Object { $_.active } | Select-Object -First 1; if (-not $p) { throw 'No active memory profile.' }; Start-Process notepad.exe -ArgumentList ('\"' + $p.memory_file + '\"') } catch { Write-Host ('Open active memory failed: ' + $_.Exception.Message) -ForegroundColor Red; Read-Host 'Press Enter to close' }"
