@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 请先退出 SPP，再启用语义回忆。
"%~dp0SatonePromptProxy.exe" --semantic-component enable
if errorlevel 1 echo 启用失败，查看上方原因。原配置与存档保留。
pause
