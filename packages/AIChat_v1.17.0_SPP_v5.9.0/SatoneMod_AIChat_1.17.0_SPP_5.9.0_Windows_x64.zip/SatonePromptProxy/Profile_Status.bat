@echo off
chcp 65001 >nul
powershell -NoProfile -Command "try { Invoke-RestMethod -Uri 'http://127.0.0.1:11435/profiles' | ConvertTo-Json -Depth 8 } catch { Write-Host $_.Exception.Message -ForegroundColor Red }"
echo.
pause
