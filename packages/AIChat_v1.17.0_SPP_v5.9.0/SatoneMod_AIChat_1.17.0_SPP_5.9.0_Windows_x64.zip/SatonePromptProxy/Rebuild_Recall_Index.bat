@echo off
chcp 65001 >nul
rem local_v1 maintenance uses the WAL-backed dashboard and durable operation IDs.
powershell -NoProfile -Command "try { $s=Invoke-RestMethod -Uri 'http://127.0.0.1:11435/selection' -TimeoutSec 3; if ($s.backend -eq 'local_v1') { Start-Process 'http://127.0.0.1:11435/dashboard'; exit 20 } } catch {}"
if errorlevel 20 exit /b 0
powershell -NoProfile -Command "try { Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:11435/recall/rebuild' | ConvertTo-Json -Depth 5 } catch { Write-Host $_.Exception.Message }"
echo.
pause
