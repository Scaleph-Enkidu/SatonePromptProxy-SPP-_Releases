@echo off
chcp 65001 >nul
rem local_v1 maintenance uses the WAL-backed dashboard and durable operation IDs.
powershell -NoProfile -Command "try { $s=Invoke-RestMethod -Uri 'http://127.0.0.1:11435/selection' -TimeoutSec 3; if ($s.backend -eq 'local_v1') { Start-Process 'http://127.0.0.1:11435/dashboard'; exit 20 } } catch {}"
if errorlevel 20 exit /b 0
echo Reloading SatoneMemory.json without resetting chat history...
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:11435/memory/reload' -TimeoutSec 180; Write-Host ''; Write-Host $r.message -ForegroundColor Green } catch { Write-Host ''; Write-Host ('Memory reload failed: ' + $_.Exception.Message) -ForegroundColor Red; if ($_.ErrorDetails.Message) { Write-Host $_.ErrorDetails.Message } }"
echo.
pause
