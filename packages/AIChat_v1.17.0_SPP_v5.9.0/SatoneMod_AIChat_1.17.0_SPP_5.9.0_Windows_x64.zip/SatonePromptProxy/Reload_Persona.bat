@echo off
chcp 65001 >nul
echo Reloading Satone persona without resetting chat history or long-term memory...
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:11435/reload-persona' -TimeoutSec 180; Write-Host ''; Write-Host $r.message -ForegroundColor Green } catch { Write-Host ''; Write-Host ('Reload failed: ' + $_.Exception.Message) -ForegroundColor Red; if ($_.ErrorDetails.Message) { Write-Host $_.ErrorDetails.Message } }"
echo.
pause
