@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo SatonePromptProxy - Set GPT-SoVITS run_api.bat path
echo ============================================================
echo.
echo Example:
echo D:\LofiMOD\GPT-SoVITS-v2pro-20250604\run_api.bat
echo.
set /p "GSV_RUN_API=Paste the full path to run_api.bat: "
if not defined GSV_RUN_API (
  echo [ERROR] No path entered.
  pause
  exit /b 1
)
if not exist "%GSV_RUN_API%" (
  echo [ERROR] File not found:
  echo %GSV_RUN_API%
  pause
  exit /b 1
)
>"%~dp0service_paths.ini" echo # SatonePromptProxy service launcher settings
>>"%~dp0service_paths.ini" echo GPT_SOVITS_RUN_API=%GSV_RUN_API%
echo.
echo [OK] Saved:
echo %GSV_RUN_API%
echo.
echo In AIChat, set "TTS service script path" to:
echo %~dp0Start_AIChat_Services.bat
echo Then enable "Auto-run TTS service on startup".
pause
