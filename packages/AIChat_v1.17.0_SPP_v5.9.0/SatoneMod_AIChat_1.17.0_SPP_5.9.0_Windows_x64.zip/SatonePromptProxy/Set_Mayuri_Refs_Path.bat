@echo off
setlocal
cd /d "%~dp0"
echo.
echo === Satone Prompt Proxy - Set Mayuri refs path ===
echo Example: D:\LofiMOD\mayuri-voice\refs
echo.
set /p "REFPATH=Enter the full path to mayuri-voice\refs: "
if not defined REFPATH (
  echo [ERROR] Path is empty.
  pause
  exit /b 1
)
if not exist "%REFPATH%" (
  echo [ERROR] Folder not found:
  echo %REFPATH%
  pause
  exit /b 1
)
set "MAYURI_REFS=%REFPATH%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p = Join-Path (Get-Location) 'config.json'; $j = Get-Content -Raw -LiteralPath $p | ConvertFrom-Json; if (-not $j.emotion_tts) { throw 'emotion_tts section not found in config.json' }; $j.emotion_tts.ref_root = $env:MAYURI_REFS; $json = $j | ConvertTo-Json -Depth 20; [System.IO.File]::WriteAllText($p, $json, (New-Object System.Text.UTF8Encoding($false)))"
if errorlevel 1 (
  echo [ERROR] Failed to update config.json
  pause
  exit /b 1
)
echo [OK] Updated emotion_tts.ref_root
echo %REFPATH%
pause
