@echo off
start "" "http://127.0.0.1:11435/usage"
