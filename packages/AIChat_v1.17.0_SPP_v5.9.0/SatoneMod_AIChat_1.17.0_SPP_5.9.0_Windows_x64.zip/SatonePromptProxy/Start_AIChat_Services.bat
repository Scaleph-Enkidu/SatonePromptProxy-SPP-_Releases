@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Satone AI Services Launcher

echo ============================================================
echo Satone AI Services Launcher
echo Starts SatonePromptProxy and GPT-SoVITS; SPP auto-starts Fun-ASR
echo ============================================================
echo.

set "GSV_RUN_API="
if exist "%~dp0service_paths.ini" (
  for /f "usebackq tokens=1,* delims==" %%A in ("%~dp0service_paths.ini") do (
    if /I "%%A"=="GPT_SOVITS_RUN_API" set "GSV_RUN_API=%%B"
  )
)

if not defined GSV_RUN_API (
  echo [ERROR] GPT-SoVITS run_api.bat path is not configured.
  echo Run Set_GPTSoVITS_RunApi_Path.bat first.
  pause
  exit /b 1
)

if not exist "%GSV_RUN_API%" (
  echo [ERROR] GPT-SoVITS run_api.bat was not found:
  echo %GSV_RUN_API%
  echo Run Set_GPTSoVITS_RunApi_Path.bat again.
  pause
  exit /b 1
)

tasklist /FI "IMAGENAME eq SatonePromptProxy.exe" 2>NUL | find /I "SatonePromptProxy.exe" >NUL
if errorlevel 1 (
  if not exist "%~dp0SatonePromptProxy.exe" (
    echo [ERROR] SatonePromptProxy.exe not found next to this launcher.
    pause
    exit /b 1
  )
  echo [START] SatonePromptProxy...
  start "SatonePromptProxy" /min "%~dp0SatonePromptProxy.exe"
  timeout /t 2 /nobreak >NUL
) else (
  echo [OK] SatonePromptProxy is already running.
)

netstat -ano -p tcp | findstr /R /C:":9880 .*LISTENING" >NUL
if not errorlevel 1 (
  echo [OK] GPT-SoVITS is already listening on port 9880.
  echo [DONE] Services are ready.
  exit /b 0
)

for %%I in ("%GSV_RUN_API%") do (
  set "GSV_DIR=%%~dpI"
  set "GSV_BAT=%%~nxI"
)

echo [START] GPT-SoVITS...
echo         %GSV_RUN_API%
pushd "%GSV_DIR%"
call "%GSV_BAT%"
set "GSV_EXIT=%ERRORLEVEL%"
popd

if not "%GSV_EXIT%"=="0" (
  echo.
  echo [WARN] GPT-SoVITS launcher exited with code %GSV_EXIT%.
)
endlocal
