@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist "%~dp0SatonePromptProxy.exe" (
  echo SatonePromptProxy.exe must be next to this launcher.
  pause
  exit /b 1
)
start "SatonePromptProxy" /min "%~dp0SatonePromptProxy.exe"
