@echo off
setlocal
echo Stopping SatonePromptProxy.exe ...
taskkill /IM SatonePromptProxy.exe /F >NUL 2>&1
if errorlevel 1 (
  echo SatonePromptProxy was not running.
) else (
  echo SatonePromptProxy stopped.
)
pause
