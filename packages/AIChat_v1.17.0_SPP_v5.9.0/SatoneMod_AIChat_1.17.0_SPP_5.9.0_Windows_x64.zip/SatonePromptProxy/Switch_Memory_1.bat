@echo off
chcp 65001 >nul
powershell -NoProfile -Command "try { $body = @{ profile_id = 'memory1' } | ConvertTo-Json; Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:11435/profiles/switch' -ContentType 'application/json' -Body $body | ConvertTo-Json -Depth 8 } catch { Write-Host $_.Exception.Message -ForegroundColor Red }"
echo.
pause
