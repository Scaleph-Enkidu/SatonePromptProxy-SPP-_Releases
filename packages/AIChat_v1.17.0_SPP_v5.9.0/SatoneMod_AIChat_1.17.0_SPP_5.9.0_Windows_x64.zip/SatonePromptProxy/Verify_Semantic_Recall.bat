@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 请先退出 SPP，再校验语义组件。
"%~dp0SatonePromptProxy.exe" --semantic-component verify
if errorlevel 1 echo 校验未通过，可继续使用关键词回忆。
pause
