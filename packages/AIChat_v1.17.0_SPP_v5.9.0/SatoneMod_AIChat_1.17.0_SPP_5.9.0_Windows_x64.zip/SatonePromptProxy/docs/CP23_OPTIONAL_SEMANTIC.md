# CP23 可选语义回忆（D 离线测试包）

主程序与模型组件分开提供：默认下载约11 MB的AIChat+SPP主程序包，按需另装约94 MB的Windows x64语义组件。程序升级复用校验通过的同一模型组件；组件身份独立记录在 `COMPONENT.json`。此前约105 MB的合并包保留为历史验证产物。本地配对验证结果见 `CP23_STAGE_D_VALIDATION_20261001.md`，最新分包安装步骤见 `CP23_TEXT_FIRST_CANDIDATE.md`。实机/干净机验收由用户执行。

文字聊天和关键词回忆无需 Python。按意思检索过去对话可选择安装本地 CPU 语义组件；缺少组件、校验失败、加载失败、进程退出或超时时，继续使用关键词回忆。语义组件不参与回合必须完成的结算效果。

主程序包不含权重或 ORT DLL；组件包包含固定四个支持文件及完整许可。将组件里的 `models` 放到SPP的EXE旁，退出SPP后使用 Verify/Enable/Disable_Semantic_Recall 工具校验与启停，详细步骤见 `CP23_SEMANTIC_INSTALL.md`。工具先备份并原子写入三个embedding键，保留其余玩家配置。历史 Python/SQLite 模型目录无法直接作为新组件使用，旧数据库原样保留。

开发验证使用 E5 revision `614241f622f53c4eeff9890bdc4f31cfecc418b3` 的官方 int8 ONNX（118,346,824 字节），ORT CPU 1.30.0、tokenizer 哈希固定。Windows x64 的组件目录内是 `model.onnx`（来自官方 `model_qint8_avx512_vnni.onnx`）、`tokenizer.json`、`onnxruntime.dll`、`onnxruntime_providers_shared.dll`；Linux x64 使用 `libonnxruntime.so.1.30.0`。文件不符合程序内固定哈希时拒绝加载。完整来源/哈希见源码仓 `docs/CP23_C1_DEPENDENCIES.json`，复审目录也附有副本。

开发机手动验证或使用启用工具后，`embedding_model_dir` 指向该组件目录，`embedding_enabled` 和 `embedding_auto_start` 同时为 `true`。程序只读取组件，不自动下载或启动 Python。启用并重启后，在Dashboard查询一次Recall，触发异步暖机与构建向量； `/recall/status` 的 `semantic_state` 显示 missing/disabled/waiting/loading/building/ready/failed，`semantic_scope` 标明对应档案。失败后的重启或 Recall 重建可重新尝试。已打开的组件进程最多一个，每次只驻留一个档案的向量。

缓存位于 SPP 运行根的 `semantic_recall_v1`；它不是存档。缓存包含分档身份、模型/tokenizer/实现指纹、维度、稳定 exchange ID、实际交流文本摘要和规范化向量，损坏或不匹配可丢弃重建。只索引已接受且实际呈现的片段，注入前仍向权威 store 复核。旧 Recall DB 和核心 WAL 不被此组件修改。

保留原 `max(sem, 0.82*sem+0.18*kw, 0.90*kw)` 分数以及 0.74/0.80/0.84 配置。E5 原始 cosine 不是置信概率：小型合成测试中的不存在事件也能得到约 0.84。因此额外限制语义独立注入只使用首位结果，raw cosine ≥0.82 且领先次位 ≥0.02；关键词仍按原规则使用。`semantic_qualified` 表示此额外筛选，管理查询仍保留原始相似度供检查。这是保守防混淆条件，不声称已用真实玩家语料校准。

语义投影最多保留最新 50,000 条已交流记录，超出时 `semantic_limited=true`；关键词索引仍覆盖完整历史，权威存档不删减。单篇语义输入取最多 60 KiB 的有效 UTF-8 前缀，再按 E5 的 512 token 上限截断。关键词搜索仍使用全文。查询等待语义的上限为 250 ms，忙碌时也可以直接回退；暖机构建在后台进行。

本地 CI、真实组件验证、内存/延迟和 fp32/int8 对照分别记录在阶段 C 验证报告中。Linux 交叉编译不代表已经在 Linux 实机推理；没有 Unity、真实厂商 API、真实玩家语料或独立 Astra 审查结果。基础程序保留Go依赖许可，组件包保留模型说明、E5项目MIT许可、ORT许可与完整第三方声明。
