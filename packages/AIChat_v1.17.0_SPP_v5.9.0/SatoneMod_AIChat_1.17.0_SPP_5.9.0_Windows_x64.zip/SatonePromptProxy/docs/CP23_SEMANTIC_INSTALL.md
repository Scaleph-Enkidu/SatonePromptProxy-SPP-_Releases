# 离线安装与启停语义回忆

[统一安装阶段二](INSTALL.zh-CN.md#stage-2) · [ONNX 详细说明](ONNX_SETUP.zh-CN.md)。本页保留原生启停工具的边界说明。

适用配对：AIChat 1.17.0 / SPP 5.9.0，Windows 64位。本组件让回忆支持换词查询，文字聊天与关键词回忆可以单独使用。模型独立分发：`Satone_Semantic_E5_small_int8_ORT_1.30.0_Windows_x64.zip`（约94 MB），主程序包约11 MB且不含模型。

1. 先安装主程序包并退出SPP。把组件包的 `models` 文件夹复制到 `SatonePromptProxy.exe` 所在目录，结构应为 `models/multilingual-e5-small/model.onnx`、`tokenizer.json` 和两个ORT DLL。不要解压到AIChat或游戏的 `BepInEx/plugins` 目录，也不要多套一层 `models/models`。
2. 双击 `Verify_Semantic_Recall.bat`，确认「组件文件校验通过」。
3. 双击 `Enable_Semantic_Recall.bat`，再启动SPP。旧配置会先备份；重启后在Dashboard检索一次Recall，触发后台暖机与向量准备，期间仍可关键词回忆。已有大量记录时准备需要时间，可在Dashboard的Recall状态查看进度。
4. 需要纯文字/关键词测试或停用时，退出SPP，双击 `Disable_Semantic_Recall.bat`，再启动。组件文件与存档保留。

程序只调整 `embedding_enabled`、`embedding_auto_start` 和启用时的 `embedding_model_dir`，保留连接、密钥、未知配置及个人存档；不下载、不启动Python、不修改旧DB或权威存档。SPP运行时工具会拒绝修改，请先正常退出。损坏文件校验失败时启用不写配置；运行时组件缺失、坏文件、失败或忙碌会退回关键词回忆。

模型安装一次即可复用。以后更新主程序时保留整个 `models` 目录及Recall缓存，重新校验；程序包不携带模型，不要求每次重新下载。模型固定revision为 `614241f622f53c4eeff9890bdc4f31cfecc418b3`，运行时为ORT CPU 1.30.0，独立组件身份见 `COMPONENT.json`。只有组件自身更新或新程序明确要求不兼容的新组件时才下载新模型包。

启停前的配置备份名为 `config.json.before-semantic-时间编号`。升级组件先退出SPP，替换完整 `models/multilingual-e5-small` 后重新校验；不混用不同版本文件。不支持的hash会拒绝加载。回退语义功能可以停用；整版本回退需恢复原程序/DLL和整套升级前配置与存档备份。

组件的四个支持文件与完整hash见 `COMPONENT.json`；`licenses` 内保留固定revision模型说明、E5项目MIT许可、ORT许可及第三方声明。模型的语义分数不是置信概率；实际换词命中仍需要玩家语料与实机测试。
