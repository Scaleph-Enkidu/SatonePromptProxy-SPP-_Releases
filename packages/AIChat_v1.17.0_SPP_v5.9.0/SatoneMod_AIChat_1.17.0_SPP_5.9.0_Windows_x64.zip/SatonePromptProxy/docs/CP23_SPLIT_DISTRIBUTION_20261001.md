# CP23 D 分发调整：主程序与模型分包（2026-10-01）

用户要求「模型单独拆出来单独发布，它太大了」。本检查点只改变本地测试包的分发和安装说明：默认主程序不含模型，语义模型、tokenizer、ORT和完整许可作为独立可选组件；未创建公开Release。

## 范围、完成条件与自审

- 主程序约11 MB；可选语义组件约94 MB，以E5 int8和ORT 1.30.0命名，组件manifest固定模型revision与四个支持文件hash。
- 首装主程序可独立启动并执行关键词查询；未装组件时verify/enable失败不改配置。
- 单独追加模型后实际worker就绪、换词查询及缓存重启通过；覆盖升级程序保留组件、缓存、配置和玩家资料。
- 两个ZIP分别检查CRC、路径、全部manifest hash、二进制、许可与旧玩家数据排除；不重建EXE/DLL，不改核心/WAL，也不重跑大存档测量。
- 两仓当前相对D受测源码只允许Markdown差异，配对安装说明保持一致。历史D/B/C失败、包与冻结检出不覆盖。

自审重点是解压层级、版本兼容边界、程序更新误删模型风险、缺组件降级、许可和两类产物的受测SHA区分。新增范围属于D分发调整，原D中高档建议保留，用户6.1-Sol/极高设置继续执行。

## 固定受测代码与本轮验证

D代码与资源原门禁保持绑定SPP `5232d58882668fc1cf446db923fc8822fec2a810` / AIChat `c5da60b686766189c30ed7d69b71dab41098f6d2`。EXE SHA256 `a05d6cdbd157152165a45b13046f95118d568f09bf1d6ea2a19c3761d56c421c`；DLL SHA256 `963d8b74ceaa9b54947f44b26cf624cdfe1f3d88d7ec4fee08d85137a5803050`。

实现者自审完成。固定文档候选SPP `512efb25475e4a7bd6cfacaae04fe04d09b5ab31` / AIChat `1ed20771a6ea7f7db4d81551483ab1900a8cbcd0` 后，第一轮四项本地检查全部通过：文档/受测源码与旧包一致性、主程序封包、模型组件封包、实际分包解压与覆盖升级。第二轮未触发。此为新授权的分发调整，不重置D2/D3既有两轮记录；本轮没有重跑Go/.NET/大WAL，引用原D代码与资源门禁，运行测试绑定这两个实际新ZIP。

文档检查的六组断言全部通过：两仓固定干净候选、各自仅Markdown差异及空白检查、双仓安装说明字节一致、EXE/DLL等于D受测二进制、证据脚本语法、原五个D已验收ZIP的大小和hash不变。两种封包脚本内置校验检查CRC、manifest逐文件hash、安全路径、默认参考录音/二进制或固定模型资产/完整许可。

实际解压验收十一分支全部通过：不带组件verify/enable不建配置、纯程序关键词启动及重启、单独追加完整组件、CLI未知大整数与合成Key及原配置备份保留、真实语义worker查询、语义缓存重启、程序覆盖保留17个组件/实际缓存/配置/旧DB/归档/玩家哨兵文件、覆盖后语义重启、缺组件回退、坏组件回退。测试目录使用中文与空格，子进程PATH为空，不依赖Python来运行Recall；开发验证脚本自身使用Python。只在隔离目录写合成输入，不触碰玩家安装。CLI的未知字段保留检查在正常SPP配置规范化之前执行，不扩大为运行时保留任意未知字段的承诺。

本轮日志根 `D:/SatoneDev/tmp/cp23-D-split/round1`，准确命令、退出码、脚本hash和日志随交付 `VALIDATION.json` / `Evidence`；解压目录和合成配置不装进用户ZIP。代码与包门禁通过，实机仍待用户。旧完整包已经装好的同一模型无需重下，本次组件更新只涉及说明，四个受支持资产hash不变。

| 新默认下载 | 字节数 | SHA256 |
|---|---:|---|
| 主程序 `CP23_AIChat_1.17.0_SPP_5.9.0.D.base.zip` | 10,723,631 | `7f7ed3c495ea5ebc1d41e07e7911867b70708df013ee940aec1627998b11d381` |
| 可选模型 `Satone_Semantic_E5_small_int8_ORT_1.30.0_Windows_x64.zip` | 93,822,611 | `9851770f7dde2fa7d106fdf39e8fbc739ca34d119bf17a3bf4773c1ccb7bb405` |

交付目录：`D:/SatoneDev/deliverables/CP23-D-Split-Test-20261001`。主程序 `CP23_AIChat_1.17.0_SPP_5.9.0.D.base.zip`；模型 `Satone_Semantic_E5_small_int8_ORT_1.30.0_Windows_x64.zip`。逐包hash和实际验收结果见包外HANDOFF / PACKAGE_ACCEPTANCE。

下一阶段仍是用户四组合实机测试，入口 `CP23_TEXT_FIRST_CANDIDATE.md`。进入条件为分包本地验收通过并备份玩家配置/存档。收到实机复现后的修复建议继续6.1-Sol/极高（沿用用户设置），原因是跨端状态和存档兼容；不自动调整模型。Unity、真实厂商API、真实TTS/ASR、玩家语料及独立Astra审查暂无新结果。

## 后续分发规则

默认提供两个独立ZIP，主程序更新不重新捆绑大模型。`tools/cp23_package.py package` 生成主程序基础包；`tools/cp23_semantic_package.py component` 只在组件需要分发或说明更新时单独封包。`bundle` 保留用于诊断和历史流程，当前默认交付不执行它。模型由固定revision、source_file和四个文件SHA256识别，不用AIChat/SPP版本代替组件身份。

发新主程序时，核对支持组件未变并复用已有下载；仅在模型/tokenizer/ORT或兼容条件变化时更新组件说明及包。程序目录覆盖更新应保留 `models`、`semantic_recall_v1`、个人配置及存档，禁止把删掉整个SPP目录当作普通升级步骤。分包实际验收脚本和保护文件hash已随本次证据保存，可用于复现该安装顺序。
