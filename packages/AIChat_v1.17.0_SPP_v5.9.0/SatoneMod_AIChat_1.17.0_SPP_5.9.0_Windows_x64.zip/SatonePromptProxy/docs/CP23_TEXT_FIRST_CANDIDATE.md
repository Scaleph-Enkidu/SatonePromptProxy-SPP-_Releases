# AIChat 1.17.0 + SPP 5.9.0 安装入口

原 CP23 测试包已转入正式配对发布。玩家请按 [四阶段安装指南](INSTALL.zh-CN.md)操作：先完成文字聊天，随后按需选装 ONNX、聪音发音、玩家语音识别，各阶段不依赖后续阶段。每阶段进阶配置可跳过。

正式主程序包为 `SatoneMod_AIChat_1.17.0_SPP_5.9.0_Windows_x64.zip`；可选模型为 `Satone_Semantic_E5_small_int8_ORT_1.30.0_Windows_x64.zip`。模型放 SPP EXE 旁；文字和关键词回忆无需 Python，模型不默认启用。兼容的主程序升级复用已校验组件，保留模型、缓存、配置、凭据和存档。

原测试包、受测 SHA、失败和性能证据继续保留；正式包的最终 hash 以 [发布清单](https://github.com/Scaleph-Enkidu/SatonePromptProxy-SPP-_Releases/blob/AIChat-v1.17.0_SPP-v5.9.0/releases/AIChat_v1.17.0_SPP_v5.9.0.json) 为准。
