# SatonePromptProxy 5.9.0：CP23 文字优先与可选语义回忆

正式配对 **AIChat 1.17.0**。2026-10-01 用户确认测试完成并批准正式发布。本文说明本版功能、安装和验证边界；发布复用受测程序，不新增运行代码。完整资产、hash、证据边界与已知限制见 [CP23 版本与发布说明](CP23_RELEASE_20261001.md)。

## 本版范围

- 默认 Recall 改为 Go 进程内关键词索引，使用已接受 / 已呈现的实际交流投影并在注入前复核权威记录，文字与关键词回忆无需 Python。
- 旧 Recall 的 pending / in_flight / unknown 结算可从持久记录恢复，不重新生成回复、不重复已确认关系 / Memory 效果；旧 SQLite 与完整权威历史保留供回退。
- 可选 E5 int8 / ONNX Runtime 1.30.0 Windows x64 组件提供语义检索；缺失 / 损坏组件继续关键词回退。原生工具校验组件 manifest 与 hash，持有运行租约后处理，停机备份并原子更新 embedding 开关 / 路径。
- 语义缓存按流式方式保存 / 载入，兼容原缓存格式与模型指纹；大存档关键词查询避免全 store 的重复克隆。模型、缓存和个人资料在主程序覆盖升级时保留。
- `/asr/status` 明确安装状态，配对 AIChat 区分未安装、未启用、加载中和就绪，语音不可用时保持文字能力。
- 本版沿用此前 Persona、关系、原版共同经历 / 剧情知识、原版台词同步、Meta 演出与情绪语音功能；本次发布收尾没有额外修改这些运行逻辑。

## 下载与安装

玩家下载公开配对主包 `SatoneMod_AIChat_1.17.0_SPP_5.9.0_Windows_x64.zip`（约11 MB），模型作为独立 `Satone_Semantic_E5_small_int8_ORT_1.30.0_Windows_x64.zip`（约94 MB）选装。SPP 私库 `SPP-v5.9.0` 附自身程序 ZIP，模型链接公开附件；权重不写源码 Git。

统一入口：[公开中文安装指南](https://github.com/Scaleph-Enkidu/SatonePromptProxy-SPP-_Releases/blob/main/docs/INSTALL.zh-CN.md)。四阶段为文字、ONNX 选装、聪音 TTS、玩家 ASR；文字不依赖后续阶段，ONNX 不是语音前置。语义组件放 SPP EXE 目录，校验 / 启用 / 禁用需停机。升级保留配置、凭据、模型、缓存、记忆、归档、旧数据库和自定义 Persona / profiles / 声线，不删除整个目录，不用 example 覆盖玩家配置。回退用升级前的配对程序与资料备份。

## 受测记录与限制

SPP 受测构建源码 `5232d58882668fc1cf446db923fc8822fec2a810`，EXE SHA-256 `a05d6cdbd157152165a45b13046f95118d568f09bf1d6ea2a19c3761d56c421c`。D代码/资源第二轮14项、原Go520顶层/1029含子项及适用单独检查通过，原完整包与后续分包实际解压记录见 [D验证](CP23_STAGE_D_VALIDATION_20261001.md) / [分包验证](CP23_SPLIT_DISTRIBUTION_20261001.md)。7项Go SKIP及未执行真实厂商API仍如实记录，不把文档HEAD称为新全代码PASS。

5万条合成WAL启动495.12秒、整管线观察峰943,693,824 B（约944MB）；原350MB门禁只覆盖worker+向量持续查询。大WAL启动优化未包含在本版。正式ZIP的大小与SHA以随附件发布的校验文件为准；各包独立核对CRC和逐文件hash，不能沿用旧候选ZIP hash。
