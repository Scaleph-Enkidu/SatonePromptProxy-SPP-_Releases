@echo off
chcp 65001 >nul
echo WARNING: This resets only the local Conversation pointer.
echo Reload_Persona.bat is enough for personality updates and keeps chat history.
echo SatoneMemory.json is NOT deleted by this reset.
echo.
set /p confirm=Type RESET to continue: 
if /I not "%confirm%"=="RESET" goto :eof
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:11435/reset'; Write-Host $r.message -ForegroundColor Yellow } catch { Write-Host $_.Exception.Message -ForegroundColor Red }"
pause
