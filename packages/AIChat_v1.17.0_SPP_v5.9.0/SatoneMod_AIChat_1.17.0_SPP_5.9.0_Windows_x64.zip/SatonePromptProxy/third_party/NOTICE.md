# CP23 optional semantic dependencies

`purego` is Ebitengine purego **v0.11.1**, Apache-2.0. Its bundled Go runtime adaptations retain their BSD licenses in `GO_RUNTIME_LICENSE`. Source: https://github.com/ebitengine/purego/tree/v0.11.1. Only imports to its own internal packages are rewritten to relative paths for this repository's `GO111MODULE=off` build; upstream Go tests/examples and unrelated optional packages are omitted; auxiliary upstream C reference fixtures remain in the source checkout. No C compiler is used.

`uniseg` is rivo/uniseg **v0.3.0**, MIT, from https://github.com/rivo/uniseg/tree/v0.3.0. Source is unchanged; tests/examples are omitted. Its Unicode grapheme segmentation is used by the pinned tokenizer normalizer.

The tokenizer implements the Unigram Viterbi / Precompiled algorithm described by HuggingFace tokenizers **v0.22.2** (Apache-2.0, https://github.com/huggingface/tokenizers/tree/v0.22.2), using the model's normalization map and vocabulary. The Darts unit bit layout follows SentencePiece's vendored darts-clone (BSD, https://github.com/google/sentencepiece/tree/master/third_party/darts_clone). E5 model/tokenizer assets are MIT (https://huggingface.co/intfloat/multilingual-e5-small); ORT is MIT (https://github.com/microsoft/onnxruntime/tree/v1.30.0). Runtime/model assets remain optional and are not embedded into the executable.

The golden fixture was generated locally using tokenizers 0.22.2 and ORT 1.30.0 from revision `614241f622f53c4eeff9890bdc4f31cfecc418b3`. It contains synthetic text and reference token IDs / normalized embeddings, not player data.
