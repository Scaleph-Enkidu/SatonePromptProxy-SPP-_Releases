# SatonePromptProxy 5.9.0：包内使用说明

正式配对 **AIChat 1.17.0**。这是**文档修订 1**：补齐包内玩家说明，不改 SPP EXE 或 AIChat DLL，程序运行版本仍为5.9.0/1.17.0。

SPP是运行在你电脑上的服务，负责把聪音的人设、记忆、关系和当前对话组织成模型请求，并提供本地回忆及语音代理。AIChat负责游戏里的界面、字幕、播放和麦克风操作；完整配对包已经包含两者。

## 核心能力

- 三套独立记忆档案、长期记忆整理、本地归档与关键词回忆；完整权威历史保留在本机。
- Persona人设、关系与压力反应、已解锁剧情知识和原版台词时间线，配合聪音的当前游戏状态。
- 可选原生ONNX语义回忆，支持换词检索历史；缺失或损坏组件时继续使用关键词回忆。
- GPT-SoVITS情绪TTS网关、Fun-ASR代理/进程管理，以及本机管理页、状态和用量查看。

文字聊天与关键词回忆不需要Python。云端聊天仍需你自己的有效模型连接、API Key和额度；本地回忆组件不负责替代聊天模型。

## 目录和文件

把整个SPP目录放到固定位置，例如 `D:\LofiMOD\SatonePromptProxy`，不要只复制EXE。首次安装应能看到：

```text
SatonePromptProxy/
  SatonePromptProxy.exe
  config.example.json
  SatonePersona_v4.6.txt
  Start_Text_Chat.bat
  Verify_Semantic_Recall.bat
  Enable_Semantic_Recall.bat
  Disable_Semantic_Recall.bat
  mayuri-voice/refs/MAY_1158_Neutral.wav
```

首次运行生成自己的 `config.json`；旧玩家的同名配置是个人资料，不能被example覆盖。模型组件另装到EXE同层的 `models/multilingual-e5-small`，不是游戏插件目录。本文位于安装包的SPP组件根目录，同层 `docs`提供完整离线教程。

## 首次安装：最小文字路线

1. 从Steam打开游戏EXE所在目录，安装BepInEx 5.4.23.5 Windows x64到EXE同层，确认有 `BepInEx` 和 `winhttp.dll`。启动一次生成插件目录和日志，再退出游戏。
2. 从配对包或AIChat 1.17.0组件取得 `AIChat.dll`、`AIChat.pdb`，放入 `BepInEx/plugins`，只留一份AIChat插件，移出旧UXPatch。将整个SPP文件夹放到固定目录。
3. 运行 `Start_Text_Chat.bat`或 `SatonePromptProxy.exe`，保留窗口运行。打开 `http://127.0.0.1:11435/`，核对版本 **5.9.0**；默认仅监听本机11435端口。
4. 进入游戏，按F9打开AIChat **1.17.0**，点击“展开设置”。在 **“SPP 与记忆（人格代理）”**里，将 **“SPP 启动文件路径：”**设为这份EXE的实际路径；需要以后由游戏启动时，可按需勾选“启动游戏时自动运行 SPP”。
5. 在 **“LLM（聊天模型与连接）”**选择所用服务，填写 **“API Key（接口密钥）”**、**“模型名称（可修改）”**，中转站按其说明填地址。点击 **“保存并应用配置”**；“（待应用）”仍是草稿。
6. 首次接入旧资料若出现记忆选择，先备份，再按需要带入或跳过；跳过不是删除旧文件。**先完成弹出的档案／旧记忆选择，再等所选服务显示“（正在使用）”后发消息**；连接激活可能正在等待选择。三个记忆档案独立，切换聊天服务不需要清空记忆。
7. 暂不装语音或模型，保留 `embedding_enabled=false`、`embedding_auto_start=false`，不勾选自动启动TTS、不开持续通话。保持SPP运行，发送一句文字问候，确认回复、字幕/历史与可输入状态恢复。

AIChat本地聊天入口为 `http://127.0.0.1:11435/v1/chat/completions`；供应商Key与云端地址通过上述聊天连接设置，不要填进TTS/ASR代理地址。只编辑或勾选选项不会立即切换服务，必须保存应用。

## 四阶段选装与成功标志

| 阶段 | 需要什么 | 先确认什么 |
| --- | --- | --- |
| ①文字 | 游戏/BepInEx、配对主程序、聊天连接 | F9发送文字得到回复；关键词回忆无需Python |
| ②ONNX语义回忆 | 独立约94MB的E5 int8/ORT模型组件 | 校验/启用后首次Recall查询，状态最终ready |
| ③聪音TTS | GPT-SoVITS环境和GPT/SoVITS声线权重 | 9880 API与实际测试WAV可播放，游戏朗读成功 |
| ④玩家ASR | Fun-ASR Python环境、模型和麦克风权限 | 9881及ASR状态正常，F8短句有真实识别结果 |

各阶段不依赖后续，ONNX不是语音前置；TTS和ASR可以分别安装。主程序带Neutral参考录音，不含完整TTS环境、声线权重或ASR模型。

安装ONNX时先停SPP，将组件包整个 `models`复制到EXE同层，先运行 `Verify_Semantic_Recall.bat`，再运行 `Enable_Semantic_Recall.bat`，重启后访问 `http://127.0.0.1:11435/recall/test?q=你的查询`触发暖机。查看 `/recall/status`确认模型、状态与当前档案索引；期间关键词回忆可用。停用时停机运行 `Disable_Semantic_Recall.bat`，模型和存档保留。

安装TTS/ASR后，在AIChat **“TTS（文字转语音）”**的 **“语音服务地址（默认连接 SPP 的 TTS 与 ASR 代理）：”**填 `http://127.0.0.1:11435`并保存应用。TTS朗读语言 `ja`、音量大于0；ASR即使不使用TTS也共用此地址。具体环境、权重和配置字段按完整语音指南设置，不能用ONNX组件替代语音模型。

## 游戏操作与资料保留

AIChat默认F9打开/关闭窗口，Enter发送、Shift+Enter换行；“反转回车键行为”会交换二者。F8按住录音、松开提交，需要先装ASR；短句测试成功后再使用“开始持续通话”。这些是游戏操作，不是SPP控制台快捷键。

升级前退出游戏、SPP和语音服务，备份AIChat CFG/history及整个SPP个人目录，再覆盖程序与工具。保留 `config.json`、连接凭据、`local_v1`、整个 `memory_profiles`、自定义人设、`models`、`semantic_recall_v1`、原版进度账本、归档/旧数据库与声线。

不要先删除整个目录或用示例覆盖配置。已有同一模型可校验复用；组件变更需停机替换完整目录，不混装文件。回退使用升级前成对程序和整套资料备份；不要擅改或截断WAL来“加速”。

## 常见排查

| 问题 | 先检查 |
| --- | --- |
| 管理页打不开/端口冲突 | SPP是否仍运行、启动日志、config.json格式，以及本机11435是否被另一进程占用 |
| 文字连接失败 | 游戏是否“保存并应用配置”且显示“（正在使用）”；Key/模型/供应商URL和401/404/429原因 |
| 模型缺失、failed或不ready | `models`层级、Verify结果、是否Enable、是否发首次Recall查询、`/recall/status`的last_error |
| 有文字无声音 | 9880 API、声线和Neutral路径、实际WAV、AIChat代理地址和音量 |
| 麦克风无识别 | `/asr/status`的实际Python/脚本/模型路径、9881、Windows录音权限 |
| 大存档启动慢 | 查日志等待恢复，不反复开第二份SPP；5万条合成WAL曾测得约495秒、整管线峰约944MB |

原“350MB”门禁只覆盖worker+向量持续查询，不是整套SPP内存保证。求助时附版本、组合、时间和复现；先隐藏Key、私人聊天和机器路径。

完整步骤见 [本包安装指南](docs/INSTALL.zh-CN.md)、[语音设置](docs/VOICE_SETUP.zh-CN.md)与[备份和隐私](docs/DATA_AND_PRIVACY.zh-CN.md)。在线查看 [统一安装指南](https://github.com/Scaleph-Enkidu/SatonePromptProxy-SPP-_Releases/blob/main/docs/INSTALL.zh-CN.md)或 [本配对Release](https://github.com/Scaleph-Enkidu/SatonePromptProxy-SPP-_Releases/releases/tag/AIChat-v1.17.0_SPP-v5.9.0)。
