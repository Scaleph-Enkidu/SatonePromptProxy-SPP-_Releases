@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
echo Close SPP before disabling semantic recall.
if exist "%~dp0SatonePromptProxy.exe" goto run_component
echo ERROR: Put this BAT beside SatonePromptProxy.exe and try again.
set "result=1"
goto finish
:run_component
"%~dp0SatonePromptProxy.exe" --semantic-component disable
set "result=%errorlevel%"
if not "%result%"=="0" echo Disable failed. See the reason above. Configuration and archives are preserved.
:finish
echo.
echo Press any key to close this window.
pause >nul
exit /b %result%
