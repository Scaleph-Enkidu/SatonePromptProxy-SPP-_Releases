@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
title SatonePromptProxy
cd /d "%~dp0"
if exist "%~dp0SatonePromptProxy.exe" goto run_proxy
echo ERROR: Put this BAT beside SatonePromptProxy.exe and try again.
set "result=1"
goto finish
:run_proxy
"%~dp0SatonePromptProxy.exe"
set "result=%errorlevel%"
:finish
if "%result%"=="0" exit /b 0
echo SPP exited with code %result%. See the reason above.
echo Press any key to close this window.
pause >nul
exit /b %result%
