@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
echo Close SPP before verifying the semantic component.
if exist "%~dp0SatonePromptProxy.exe" goto run_component
echo ERROR: Put this BAT beside SatonePromptProxy.exe and try again.
set "result=1"
goto finish
:run_component
"%~dp0SatonePromptProxy.exe" --semantic-component verify
set "result=%errorlevel%"
if not "%result%"=="0" echo Verification failed. See the reason above. Keyword recall remains available.
:finish
echo.
echo Press any key to close this window.
pause >nul
exit /b %result%
